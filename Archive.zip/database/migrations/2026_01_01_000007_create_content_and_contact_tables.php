<?php

return [
    'up' => [
        "CREATE TABLE page_sections (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            page_id BIGINT UNSIGNED NULL,
            section_key VARCHAR(100) NOT NULL,
            section_type VARCHAR(100) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            config_json LONGTEXT NULL,
            created_at TIMESTAMP NULL,
            updated_at TIMESTAMP NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        "CREATE TABLE page_section_translations (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            page_section_id BIGINT UNSIGNED NOT NULL,
            language_code VARCHAR(10) NOT NULL,
            title VARCHAR(255) NULL,
            subtitle VARCHAR(500) NULL,
            body_text LONGTEXT NULL,
            data_json LONGTEXT NULL,
            created_at TIMESTAMP NULL,
            updated_at TIMESTAMP NULL,
            UNIQUE KEY uq_page_section_lang (page_section_id, language_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        "CREATE TABLE media (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            file_name VARCHAR(255) NOT NULL,
            original_name VARCHAR(255) NOT NULL,
            extension VARCHAR(20) NULL,
            mime_type VARCHAR(100) NULL,
            file_size BIGINT UNSIGNED NULL,
            storage_disk VARCHAR(50) NOT NULL DEFAULT 'public',
            storage_path VARCHAR(500) NOT NULL,
            checksum VARCHAR(100) NULL,
            width INT NULL,
            height INT NULL,
            uploaded_by BIGINT UNSIGNED NULL,
            created_at TIMESTAMP NULL,
            updated_at TIMESTAMP NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        "CREATE TABLE contact_submissions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            mobile VARCHAR(100) NULL,
            company_name VARCHAR(255) NULL,
            country VARCHAR(255) NULL,
            subject VARCHAR(255) NULL,
            message LONGTEXT NOT NULL,
            language_code VARCHAR(10) NOT NULL DEFAULT 'fa',
            source_page VARCHAR(100) NULL,
            status VARCHAR(50) NOT NULL DEFAULT 'new',
            ip_address VARCHAR(100) NULL,
            user_agent VARCHAR(500) NULL,
            created_at TIMESTAMP NULL,
            updated_at TIMESTAMP NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",
        "CREATE TABLE seo_entries (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            entity_type VARCHAR(100) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL,
            language_code VARCHAR(10) NOT NULL,
            meta_title VARCHAR(255) NULL,
            meta_description VARCHAR(500) NULL,
            canonical_url VARCHAR(500) NULL,
            robots_index TINYINT(1) NOT NULL DEFAULT 1,
            robots_follow TINYINT(1) NOT NULL DEFAULT 1,
            og_title VARCHAR(255) NULL,
            og_description VARCHAR(500) NULL,
            og_image_media_id BIGINT UNSIGNED NULL,
            schema_json LONGTEXT NULL,
            created_at TIMESTAMP NULL,
            updated_at TIMESTAMP NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
    ],
    'down' => [
        'DROP TABLE IF EXISTS seo_entries;',
        'DROP TABLE IF EXISTS contact_submissions;',
        'DROP TABLE IF EXISTS media;',
        'DROP TABLE IF EXISTS page_section_translations;',
        'DROP TABLE IF EXISTS page_sections;'
    ]
];
