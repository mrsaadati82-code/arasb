<?php

return [
    'tables' => [
        [
            'name' => 'pages',
            'columns' => [
                'id' => 'increments',
                'type' => 'string:50',
                'slug_base' => 'string:150',
                'status' => 'string:30',
                'template_key' => 'string:100',
                'published_at' => 'timestamp_nullable',
                'sort_order' => 'integer',
                'created_at' => 'timestamp',
                'updated_at' => 'timestamp',
            ],
        ],
        [
            'name' => 'page_translations',
            'columns' => [
                'id' => 'increments',
                'page_id' => 'integer',
                'language_code' => 'string:5',
                'title' => 'string:255',
                'slug' => 'string:255',
                'excerpt' => 'text_nullable',
                'content_json' => 'longtext_nullable',
                'meta_title' => 'string:255_nullable',
                'meta_description' => 'text_nullable',
                'created_at' => 'timestamp',
                'updated_at' => 'timestamp',
            ],
        ],
    ],
];
