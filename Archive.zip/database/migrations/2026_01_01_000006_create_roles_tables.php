<?php

return [
    'tables' => [
        [
            'name' => 'roles',
            'columns' => [
                'id' => 'increments',
                'name' => 'string:150',
                'key' => 'string:100',
                'description' => 'text_nullable',
                'created_at' => 'timestamp',
                'updated_at' => 'timestamp',
            ],
        ],
        [
            'name' => 'user_roles',
            'columns' => [
                'id' => 'increments',
                'user_id' => 'integer',
                'role_id' => 'integer',
                'created_at' => 'timestamp',
            ],
        ],
    ],
];
