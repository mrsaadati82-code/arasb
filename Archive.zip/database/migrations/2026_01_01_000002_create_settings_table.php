<?php

return [
    'table' => 'settings',
    'columns' => [
        'id' => 'increments',
        'group_key' => 'string:100',
        'key' => 'string:150',
        'value_type' => 'string:30',
        'value_text' => 'text_nullable',
        'value_json' => 'longtext_nullable',
        'is_public' => 'boolean',
        'created_at' => 'timestamp',
        'updated_at' => 'timestamp',
    ],
];
