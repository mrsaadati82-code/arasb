<?php

return [
    'tables' => [
        [
            'name' => 'product_categories',
            'columns' => [
                'id' => 'increments',
                'parent_id' => 'integer_nullable',
                'slug_base' => 'string:150',
                'status' => 'string:30',
                'sort_order' => 'integer',
                'created_at' => 'timestamp',
                'updated_at' => 'timestamp',
            ],
        ],
        [
            'name' => 'products',
            'columns' => [
                'id' => 'increments',
                'product_category_id' => 'integer',
                'sku' => 'string:100_nullable',
                'slug_base' => 'string:150',
                'status' => 'string:30',
                'is_featured' => 'boolean',
                'published_at' => 'timestamp_nullable',
                'created_at' => 'timestamp',
                'updated_at' => 'timestamp',
            ],
        ],
        [
            'name' => 'product_translations',
            'columns' => [
                'id' => 'increments',
                'product_id' => 'integer',
                'language_code' => 'string:5',
                'title' => 'string:255',
                'slug' => 'string:255',
                'short_description' => 'text_nullable',
                'full_description' => 'longtext_nullable',
                'meta_title' => 'string:255_nullable',
                'meta_description' => 'text_nullable',
                'created_at' => 'timestamp',
                'updated_at' => 'timestamp',
            ],
        ],
    ],
];
