<?php

return [
    'table' => 'users',
    'columns' => [
        'id' => 'increments',
        'full_name' => 'string:150',
        'email' => 'string:190',
        'password' => 'string:255',
        'is_active' => 'boolean',
        'last_login_at' => 'timestamp_nullable',
        'created_at' => 'timestamp',
        'updated_at' => 'timestamp',
    ],
];
