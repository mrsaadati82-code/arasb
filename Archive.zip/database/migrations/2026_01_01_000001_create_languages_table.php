<?php

return [
    'table' => 'languages',
    'columns' => [
        'id' => 'increments',
        'code' => 'string:5',
        'name' => 'string:100',
        'native_name' => 'string:100',
        'direction' => 'string:3',
        'is_default' => 'boolean',
        'is_active' => 'boolean',
        'sort_order' => 'integer',
        'created_at' => 'timestamp',
        'updated_at' => 'timestamp',
    ],
];
