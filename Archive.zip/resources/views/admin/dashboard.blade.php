@extends('layouts.admin')

@section('content')
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon amber">📦</div>
        <div class="stat-value">{{ $productCount ?? 0 }}</div>
        <div class="stat-label">محصولات منتشرشده</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">📬</div>
        <div class="stat-value">{{ $newMessages ?? 0 }}</div>
        <div class="stat-label">پیام‌های جدید</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue">🌐</div>
        <div class="stat-value">{{ $activeLanguages ?? 3 }}</div>
        <div class="stat-label">زبان‌های فعال</div>
    </div>
</div>

<div class="panel-card">
    <h2>دسترسی سریع</h2>
    <div class="quick-links">
        <a class="quick-link" href="/admin/products">
            <div class="ql-icon">📦</div>
            <div class="ql-text">
                <span class="ql-title">محصولات</span>
                <span class="ql-sub">مدیریت محصولات و ترجمه‌ها</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/home-sections">
            <div class="ql-icon">🏠</div>
            <div class="ql-text">
                <span class="ql-title">صفحه اصلی</span>
                <span class="ql-sub">سکشن‌های صفحه اصلی</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/contact-submissions">
            <div class="ql-icon">📬</div>
            <div class="ql-text">
                <span class="ql-title">پیام‌های تماس</span>
                <span class="ql-sub">مشاهده پیام‌های دریافتی</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/settings">
            <div class="ql-icon">⚙️</div>
            <div class="ql-text">
                <span class="ql-title">تنظیمات</span>
                <span class="ql-sub">تنظیمات عمومی و ظاهر</span>
            </div>
        </a>
    </div>
</div>
@endsection
