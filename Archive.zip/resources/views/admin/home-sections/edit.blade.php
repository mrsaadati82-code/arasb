@extends('layouts.admin')

@section('content')
<div class="panel-head">
    <div>
        <h1>✏️ ویرایش سکشن صفحه اصلی</h1>
        <p class="muted">محتوای هر سکشن را برای فارسی، انگلیسی و عربی مدیریت کنید</p>
    </div>
    <a class="admin-btn secondary" href="/admin/home-sections">↩️ بازگشت</a>
</div>

@if($saved)
<div class="notice success">✅ تغییرات سکشن با موفقیت ذخیره شد.</div>
@endif

<form method="POST" action="/admin/home-sections/save" class="form-stack">
    <input type="hidden" name="id" value="{{ $item['id'] }}">

    <div class="panel-card">
        <h3>📋 اطلاعات پایه</h3>
        <div class="form-grid two">
            <div>
                <label class="field-label">کلید سکشن</label>
                <input class="field" name="section_key" value="{{ $item['section_key'] ?? '' }}" placeholder="hero">
            </div>
            <div>
                <label class="field-label">نوع سکشن</label>
                <input class="field" name="section_type" value="{{ $item['section_type'] ?? '' }}" placeholder="hero">
            </div>
            <div>
                <label class="field-label">ترتیب نمایش</label>
                <input class="field" name="sort_order" type="number" value="{{ $item['sort_order'] ?? '0' }}">
            </div>
            <div>
                <label class="field-label">وضعیت</label>
                <select class="field" name="is_active">
                    <option value="1">فعال</option>
                    <option value="0">غیرفعال</option>
                </select>
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🇬🇧 ترجمه English</h3>
        <div class="form-grid">
            <div>
                <label class="field-label">Badge / برچسب</label>
                <input class="field" name="title_en" value="{{ $item['translations']['en']['badge'] ?? $item['translations']['en']['title'] ?? '' }}" placeholder="Badge text">
            </div>
            <div>
                <label class="field-label">عنوان</label>
                <input class="field" name="subtitle_en" value="{{ $item['translations']['en']['subtitle'] ?? '' }}" placeholder="Title">
            </div>
            <div>
                <label class="field-label">توضیحات</label>
                <textarea class="field" name="description_en" rows="3" placeholder="Description">{{ $item['translations']['en']['description'] ?? '' }}</textarea>
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🇮🇷 ترجمه فارسی</h3>
        <div class="form-grid">
            <div>
                <label class="field-label">برچسب</label>
                <input class="field" name="title_fa" value="{{ $item['translations']['fa']['badge'] ?? $item['translations']['fa']['title'] ?? '' }}" placeholder="متن برچسب">
            </div>
            <div>
                <label class="field-label">عنوان</label>
                <input class="field" name="subtitle_fa" value="{{ $item['translations']['fa']['subtitle'] ?? '' }}" placeholder="عنوان">
            </div>
            <div>
                <label class="field-label">توضیحات</label>
                <textarea class="field" name="description_fa" rows="3" placeholder="توضیحات">{{ $item['translations']['fa']['description'] ?? '' }}</textarea>
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🇸🇦 ترجمه العربية</h3>
        <div class="form-grid">
            <div>
                <label class="field-label">شارة</label>
                <input class="field" name="title_ar" value="{{ $item['translations']['ar']['badge'] ?? $item['translations']['ar']['title'] ?? '' }}" placeholder="نص الشارة">
            </div>
            <div>
                <label class="field-label">عنوان</label>
                <input class="field" name="subtitle_ar" value="{{ $item['translations']['ar']['subtitle'] ?? '' }}" placeholder="العنوان">
            </div>
            <div>
                <label class="field-label">الوصف</label>
                <textarea class="field" name="description_ar" rows="3" placeholder="الوصف">{{ $item['translations']['ar']['description'] ?? '' }}</textarea>
            </div>
        </div>
    </div>

    <div class="actions-row">
        <button class="admin-btn primary" type="submit">💾 ذخیره سکشن</button>
    </div>
</form>
@endsection
