@extends('layouts.admin')

@section('content')
<div class="panel-head">
    <div>
        <h1>📬 پیام‌های تماس</h1>
        <p class="muted">پیام‌های ثبت‌شده از فرم تماس سایت</p>
    </div>
</div>

@if($hasItems)
@foreach($items as $item)
<div class="panel-card" style="margin-bottom:14px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <div style="display:flex; align-items:center; gap:10px;">
            @if($item['status'] === 'new')
            <span class="badge warning">🆕 جدید</span>
            @else
            <span class="badge neutral">{{ $item['status'] ?? '' }}</span>
            @endif
            <span class="badge info">{{ $item['language_code'] ?? 'en' }}</span>
        </div>
        <span style="font-size:12px; color:var(--text-muted);">{{ $item['created_at'] ?? '' }}</span>
    </div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:12px;">
        <div>
            <span style="font-size:11px; color:var(--text-muted);">نام</span><br>
            <strong>{{ $item['full_name'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--text-muted);">ایمیل</span><br>
            <strong>{{ $item['email'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--text-muted);">موبایل</span><br>
            <strong>{{ $item['mobile'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--text-muted);">موضوع</span><br>
            <strong>{{ $item['subject'] ?? '-' }}</strong>
        </div>
    </div>
    <div style="background:#f8fafc; border:1px solid var(--border); border-radius:var(--radius); padding:12px 14px; font-size:14px; line-height:1.7;">
        {{ $item['message'] ?? '-' }}
    </div>
</div>
@endforeach
@else
<div class="panel-card">
    <div class="empty-state">
        <div class="empty-icon">📭</div>
        <p>هنوز پیامی دریافت نشده است.</p>
    </div>
</div>
@endif
@endsection
