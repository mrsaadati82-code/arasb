@extends('layouts.admin')

@section('content')
<div class="panel-head">
    <div>
        <h1>⚙️ تنظیمات سایت</h1>
        <p class="muted">تنظیمات پایه برند، تماس، زبان پیش‌فرض و فونت فعال</p>
    </div>
</div>

@if($saved)
<div class="notice success">✅ تنظیمات با موفقیت ذخیره شد.</div>
@endif

<form method="POST" action="/admin/settings/save" class="form-stack">
    <div class="panel-card">
        <h3>🏢 اطلاعات شرکت</h3>
        <div class="form-grid two">
            <div>
                <label class="field-label">نام شرکت</label>
                <input class="field" name="company_name" value="{{ $settings['company_name'] }}" placeholder="ARASB Trading">
            </div>
            <div>
                <label class="field-label">عنوان سایت</label>
                <input class="field" name="site_title" value="{{ $settings['site_title'] }}" placeholder="ARASB Trading">
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>📞 اطلاعات تماس</h3>
        <div class="form-grid two">
            <div>
                <label class="field-label">ایمیل</label>
                <input class="field" name="email" type="email" value="{{ $settings['email'] }}" placeholder="info@arasbtrading.com">
            </div>
            <div>
                <label class="field-label">تلفن</label>
                <input class="field" name="phone" value="{{ $settings['phone'] }}" placeholder="+98 21 8888 8888">
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🌐 تنظیمات سایت</h3>
        <div class="form-grid two">
            <div>
                <label class="field-label">دامنه اصلی</label>
                <input class="field" name="primary_domain" value="{{ $settings['primary_domain'] }}" placeholder="arasbtrading.com">
            </div>
            <div>
                <label class="field-label">زبان پیش‌فرض</label>
                <select class="field" name="default_language">
                    <option value="fa" @if($settings['default_language'] === 'fa') selected @endif>فارسی</option>
                    <option value="en" @if($settings['default_language'] === 'en') selected @endif>English</option>
                    <option value="ar" @if($settings['default_language'] === 'ar') selected @endif>العربية</option>
                </select>
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🎨 ظاهر و فونت</h3>
        <div class="form-grid two">
            <div>
                <label class="field-label">فونت فعال (پنل مدیریت + سایت)</label>
                <select class="field" name="font_family" id="font-select">
                    @foreach($fontOptions as $item)
                    <option value="{{ $item['value'] }}" @if($settings['font_family'] === $item['value']) selected @endif>{{ $item['label'] }}</option>
                    @endforeach
                </select>
                <p style="margin-top:8px; font-size:12px; color:var(--text-muted);">فونت انتخابی روی پنل مدیریت و صفحات سایت اعمال می‌شود.</p>
            </div>
            <div>
                <label class="field-label">پیش‌نمایش فونت</label>
                <div id="font-preview" style="padding:14px; background:#f8fafc; border:1px solid var(--border); border-radius:var(--radius); font-size:18px; min-height:52px; line-height:1.6;">
                    متن نمونه — Sample — مثال
                </div>
            </div>
        </div>
    </div>

    <div class="actions-row">
        <button class="admin-btn primary" type="submit">💾 ذخیره تنظیمات</button>
    </div>
</form>

<script>
(function(){
  var select = document.getElementById('font-select');
  var preview = document.getElementById('font-preview');
  if (!select || !preview) return;

  var fontMap = {
    'default': 'Tahoma, Arial, sans-serif',
    'dana': "'Dana', Tahoma, Arial, sans-serif",
    'iransans': "'IRANSans', Tahoma, Arial, sans-serif",
    'iranyekan': "'IRANYekan', Tahoma, Arial, sans-serif",
    'kalameh': "'Kalameh', Tahoma, Arial, sans-serif",
    'peyda': "'Peyda', Tahoma, Arial, sans-serif"
  };

  function updatePreview() {
    var font = fontMap[select.value] || fontMap['default'];
    preview.style.fontFamily = font;
  }

  select.addEventListener('change', updatePreview);
  updatePreview();
})();
</script>
@endsection
