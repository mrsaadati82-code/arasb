<!DOCTYPE html>
<html lang="fa" dir="rtl" data-arasb-font="{{ $arasbFont }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'پنل مدیریت آراسب' }}</title>
    <link rel="stylesheet" href="/assets/css/fonts.css">
    <link rel="stylesheet" href="/font-css.php">
    <link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body class="admin-body" data-arasb-font="{{ $arasbFont }}">

<!-- Mobile menu toggle -->
<button class="admin-menu-toggle" onclick="document.querySelector('.admin-sidebar').classList.toggle('open'); document.querySelector('.admin-overlay').classList.toggle('open');">&#9776;</button>
<div class="admin-overlay" onclick="document.querySelector('.admin-sidebar').classList.remove('open'); this.classList.remove('open');"></div>

<div class="admin-shell">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <div class="admin-brand">
                ARASB<span class="brand-accent">TRADING</span>
                <span class="brand-sub">ADMIN</span>
            </div>
        </div>
        <nav class="admin-nav">
            @foreach($navItems as $nav)
            <a href="{{ $nav['url'] }}" class="{{ $nav['activeClass'] }}">
                <span class="nav-icon">{{ $nav['icon'] }}</span>
                {{ $nav['label'] }}
            </a>
            @endforeach
        </nav>
        <div class="admin-sidebar-footer">
            <form method="POST" action="/admin/logout">
                <button class="logout-btn" type="submit">&#128274; خروج از حساب</button>
            </form>
        </div>
    </aside>
    <section class="admin-main">
        <header class="admin-topbar">
            <div>
                <div class="admin-topbar-title">{{ $title ?? 'پنل مدیریت' }}</div>
            </div>
            <div class="admin-topbar-sub">پنل مدیریت آراسب تریدینگ</div>
        </header>
        <div class="admin-content">
            @yield('content')
        </div>
    </section>
</div>

</body>
</html>
