<?php

namespace App\Http\Controllers\Api;

use App\Support\DataStore;

class PublicApiController
{
    private function json(array $payload, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    private function getLocale(): string
    {
        return trim($_GET['locale'] ?? 'en');
    }

    public function settings(): void
    {
        $items = DataStore::read('settings');
        $settings = [];

        foreach ($items as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        $this->json([
            'success' => true,
            'data' => $settings,
        ]);
    }

    public function languages(): void
    {
        $this->json([
            'success' => true,
            'data' => DataStore::read('languages'),
        ]);
    }

    public function homeSections(): void
    {
        $locale = $this->getLocale();
        $items = DataStore::read('home_sections');
        $result = [];

        foreach ($items as $item) {
            $result[] = [
                'id' => $item['id'] ?? 0,
                'page_key' => $item['page_key'] ?? 'home',
                'section_key' => $item['section_key'] ?? '',
                'section_type' => $item['section_type'] ?? 'content',
                'is_active' => (int)($item['is_active'] ?? 0),
                'sort_order' => (int)($item['sort_order'] ?? 0),
                'translation' => $item['translations'][$locale] ?? ($item['translations']['en'] ?? []),
                'translations' => $item['translations'] ?? [],
            ];
        }

        $this->json([
            'success' => true,
            'locale' => $locale,
            'data' => $result,
        ]);
    }

    public function products(): void
    {
        $locale = $this->getLocale();
        $items = DataStore::read('products');
        $result = [];

        foreach ($items as $item) {
            // Only show published products
            $status = $item['status'] ?? '';
            if ($status !== 'published' && $status !== 'منتشرشده') {
                continue;
            }

            // Get translation for current locale, fallback to English
            $translation = $item['translations'][$locale] ?? ($item['translations']['en'] ?? []);

            // Get category in current locale
            $category = '';
            if (isset($item['category'])) {
                if (is_array($item['category'])) {
                    $category = $item['category'][$locale] ?? ($item['category']['en'] ?? '');
                } else {
                    $category = $item['category'];
                }
            }

            $result[] = [
                'id' => $item['id'] ?? 0,
                'slug' => $item['slug'] ?? '',
                'image' => $item['image'] ?? '/default-product.jpg',
                'category' => $category,
                'sort_order' => (int)($item['sort_order'] ?? 0),
                'title' => $translation['title'] ?? '',
                'description' => $translation['description'] ?? '',
            ];
        }

        // Sort by sort_order
        usort($result, function ($a, $b) {
            return $a['sort_order'] <=> $b['sort_order'];
        });

        $this->json([
            'success' => true,
            'locale' => $locale,
            'data' => $result,
        ]);
    }

    public function contactSubmit(): void
    {
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $companyName = trim($_POST['company_name'] ?? '');
        $country = trim($_POST['country'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $languageCode = trim($_POST['language_code'] ?? 'en');
        $sourcePage = trim($_POST['source_page'] ?? 'contact');

        if ($fullName === '' || $email === '' || $message === '') {
            $this->json([
                'success' => false,
                'message' => 'Required fields are missing.',
            ], 422);
        }

        $items = DataStore::read('contact_submissions');
        $items[] = [
            'id' => count($items) + 1,
            'full_name' => $fullName,
            'email' => $email,
            'mobile' => $mobile,
            'company_name' => $companyName,
            'country' => $country,
            'subject' => $subject,
            'message' => $message,
            'language_code' => $languageCode,
            'source_page' => $sourcePage,
            'status' => 'new',
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => date('c'),
        ];

        DataStore::write('contact_submissions', $items);

        $this->json([
            'success' => true,
            'message' => 'Your message has been received successfully.',
        ]);
    }
}
