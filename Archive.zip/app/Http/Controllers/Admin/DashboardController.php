<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class DashboardController
{
    public function index(): array
    {
        $products = DataStore::read('products');
        $publishedCount = 0;
        foreach ($products as $p) {
            $status = $p['status'] ?? '';
            if ($status === 'published' || $status === 'منتشرشده') {
                $publishedCount++;
            }
        }

        $submissions = DataStore::read('contact_submissions');
        $newMessages = 0;
        foreach ($submissions as $s) {
            if (($s['status'] ?? '') === 'new') {
                $newMessages++;
            }
        }

        $languages = DataStore::read('languages');
        $activeLanguages = 0;
        foreach ($languages as $l) {
            if (!empty($l['is_active'])) {
                $activeLanguages++;
            }
        }

        return [
            'view' => 'admin.dashboard',
            'data' => [
                'title' => 'داشبورد',
                'productCount' => $publishedCount,
                'newMessages' => $newMessages,
                'activeLanguages' => $activeLanguages,
            ],
        ];
    }
}
