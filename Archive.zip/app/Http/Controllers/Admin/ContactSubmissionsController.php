<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class ContactSubmissionsController
{
    public function index(): array
    {
        $items = array_reverse(DataStore::read('contact_submissions'));

        return [
            'view' => 'admin.contact-submissions.index',
            'data' => [
                'title' => 'پیام‌های تماس',
                'items' => $items,
                'hasItems' => !empty($items),
            ],
        ];
    }
}
