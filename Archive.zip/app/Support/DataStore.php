<?php

namespace App\Support;

class DataStore
{
    public static function read(string $name): array
    {
        $path = dirname(__DIR__, 2) . '/storage/data/' . $name . '.json';
        if (!file_exists($path)) {
            return [];
        }

        $json = file_get_contents($path);
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }

    public static function write(string $name, array $data): bool
    {
        $path = dirname(__DIR__, 2) . '/storage/data/' . $name . '.json';
        return (bool) file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public static function findById(string $name, int $id): ?array
    {
        $items = self::read($name);
        foreach ($items as $item) {
            if ((int)($item['id'] ?? 0) === $id) {
                return $item;
            }
        }
        return null;
    }
}
