<?php

declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/../../app/Support/helpers.php';
require_once __DIR__ . '/../../app/Support/DataStore.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/DashboardController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/LanguagesController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/PagesController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/ProductsController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/HomeSectionsController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/ContactSubmissionsController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Admin/SettingsController.php';
require_once __DIR__ . '/../../app/Http/Controllers/Auth/AdminLoginController.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    $requestUri = $_SERVER['REQUEST_URI'] ?? '/admin';
    $path = parse_url($requestUri, PHP_URL_PATH) ?: '/admin';

    $path = preg_replace('#/+#', '/', $path);
    $path = rtrim($path, '/');
    $path = $path === '' ? '/admin' : $path;

    if (str_starts_with($path, '/admin/index.php')) {
        $path = substr($path, strlen('/admin/index.php'));
        $path = '/admin' . ($path === '' ? '' : $path);
    }

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    $routeMap = [
        'GET' => [
            '/admin' => ['App\\Http\\Controllers\\Admin\\DashboardController', 'index', true],
            '/admin/login' => ['App\\Http\\Controllers\\Auth\\AdminLoginController', 'showLogin', false],
            '/admin/settings' => ['App\\Http\\Controllers\\Admin\\SettingsController', 'index', true],
            '/admin/languages' => ['App\\Http\\Controllers\\Admin\\LanguagesController', 'index', true],
            '/admin/pages' => ['App\\Http\\Controllers\\Admin\\PagesController', 'index', true],
            '/admin/pages/edit' => ['App\\Http\\Controllers\\Admin\\PagesController', 'edit', true],
            '/admin/products' => ['App\\Http\\Controllers\\Admin\\ProductsController', 'index', true],
            '/admin/products/edit' => ['App\\Http\\Controllers\\Admin\\ProductsController', 'edit', true],
            '/admin/home-sections' => ['App\\Http\\Controllers\\Admin\\HomeSectionsController', 'index', true],
            '/admin/home-sections/edit' => ['App\\Http\\Controllers\\Admin\\HomeSectionsController', 'edit', true],
            '/admin/contact-submissions' => ['App\\Http\\Controllers\\Admin\\ContactSubmissionsController', 'index', true],
        ],
        'POST' => [
            '/admin/login' => ['App\\Http\\Controllers\\Auth\\AdminLoginController', 'login', false],
            '/admin/logout' => ['App\\Http\\Controllers\\Auth\\AdminLoginController', 'logout', true],
            '/admin/pages/save' => ['App\\Http\\Controllers\\Admin\\PagesController', 'save', true],
            '/admin/products/save' => ['App\\Http\\Controllers\\Admin\\ProductsController', 'save', true],
            '/admin/settings/save' => ['App\\Http\\Controllers\\Admin\\SettingsController', 'save', true],
            '/admin/home-sections/save' => ['App\\Http\\Controllers\\Admin\\HomeSectionsController', 'save', true],
        ],
    ];

    if (!isset($routeMap[$method][$path])) {
        http_response_code(404);
        echo 'ARASB Admin - Page not found';
        exit;
    }

    [$class, $action, $requiresAuth] = $routeMap[$method][$path];

    if ($requiresAuth && !arasb_auth_check()) {
        arasb_redirect('/admin/login');
    }

    if (!$requiresAuth && $path === '/admin/login' && $method === 'GET' && arasb_auth_check()) {
        arasb_redirect('/admin');
    }

    $controller = new $class();
    $result = $controller->{$action}();

    if (is_array($result) && isset($result['view'])) {
        arasb_view($result['view'], $result['data'] ?? []);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo '<h1>ARASB Admin Debug Error</h1>';
    echo '<pre style="white-space:pre-wrap;direction:ltr;text-align:left;padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;">';
    echo htmlspecialchars($e->getMessage() . "\n\n" . $e->getTraceAsString(), ENT_QUOTES, 'UTF-8');
    echo '</pre>';
}
