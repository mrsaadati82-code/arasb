<?php

declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require_once __DIR__ . '/../../app/Support/helpers.php';
require_once __DIR__ . '/../../app/Support/DataStore.php';
require_once __DIR__ . '/../../app/Http/Controllers/Api/PublicApiController.php';

try {
    // CORS headers for API requests from public site
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin) {
        header('Access-Control-Allow-Origin: ' . rtrim($origin, '/'));
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
    }
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    $requestUri = $_SERVER['REQUEST_URI'] ?? '/api';
    $path = parse_url($requestUri, PHP_URL_PATH) ?: '/api';
    $path = preg_replace('#/+#', '/', $path);
    $path = rtrim($path, '/');
    $path = $path === '' ? '/api' : $path;

    if (str_starts_with($path, '/api/index.php')) {
        $path = substr($path, strlen('/api/index.php'));
        $path = '/api' . ($path === '' ? '' : $path);
    }

    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $controller = new App\Http\Controllers\Api\PublicApiController();

    if ($path === '/api/settings' && $method === 'GET') {
        $controller->settings();
    }

    if ($path === '/api/languages' && $method === 'GET') {
        $controller->languages();
    }

    if ($path === '/api/home-sections' && $method === 'GET') {
        $controller->homeSections();
    }

    if ($path === '/api/products' && $method === 'GET') {
        $controller->products();
    }

    if ($path === '/api/contact-submit' && $method === 'POST') {
        $controller->contactSubmit();
    }

    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'API route not found.'], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
}
