# تغییرات نسخه 2.1.0

## ویژگی‌های جدید

### 🗄️ پشتیبانی از MySQL
- **Database Class**: کلاس جدید برای مدیریت اتصال به دیتابیس
- **Automatic Migration**: اجرای خودکار migration ها
- **Smart Fallback**: اگر MySQL در دسترس نباشد، از JSON استفاده می‌شود
- **DataStore Upgrade**: DataStore اکنون از MySQL پشتیبانی می‌کند

### 📁 Media Manager
- **آپلود فایل**: پشتیبانی از تصاویر، PDF، Word، Excel
- **حداکثر حجم**: 10 مگابایت
- **مدیریت**: مشاهده، کپی path، حذف
- **Grid View**: نمایش گالری تصاویر
- **Database Integration**: ذخیره اطلاعات در دیتابیس یا JSON

### 🔧 نصب‌کننده خودکار (install.php)
- ایجاد خودکار دیتابیس
- اجرای تمام migration ها
- Seed داده‌های اولیه از JSON
- ایجاد کاربر admin
- رابط کاربری فارسی
- قابل اجرا از طریق مرورگر یا SSH

## تغییرات فنی

### Migration های جدید (SQL-based)
```
001_create_languages_table.php
002_create_settings_table.php
003_create_pages_table.php
004_create_products_table.php
005_create_users_table.php
006_create_home_sections_table.php
007_create_contact_submissions_table.php
008_create_media_table.php
```

### فایل‌های جدید
- `app/Support/Database.php` - کلاس اتصال به دیتابیس
- `app/Support/MediaManager.php` - مدیریت فایل‌ها
- `app/Http/Controllers/Admin/MediaController.php` - کنترلر Media
- `resources/views/admin/media/index.blade.php` - ویوی Media
- `config/database.php` - تنظیمات دیتابیس
- `install.php` - نصب‌کننده خودکار
- `.env` - تنظیمات محیطی
- `.env.example` - نمونه تنظیمات
- `public/uploads/` - پوشه آپلود فایل‌ها

### فایل‌های تغییر یافته
- `app/Support/DataStore.php` - پشتیبانی از MySQL با fallback به JSON
- `public/admin/index.php` - اضافه شدن Media routes
- `VERSION.txt` - آپدیت نسخه

## نحوه استفاده

### نصب اولیه
1. فایل‌ها را آپلود کنید
2. فایل `.env` را ویرایش کنید
3. `install.php` را اجرا کنید
4. فایل `install.php` را حذف کنید
5. وارد پنل شوید: `admin` / `admin123`

### استفاده از Media Manager
1. وارد پنل مدیریت شوید
2. به بخش "رسانه" بروید
3. فایل‌ها را آپلود کنید
4. Path فایل را کپی کنید
5. در محصولات یا صفحات استفاده کنید

## سازگاری

### Backward Compatibility
- ✅ تمام قابلیت‌های قبلی حفظ شده
- ✅ UI تغییر نکرده
- ✅ API endpoints بدون تغییر
- ✅ اگر MySQL نباشد، از JSON استفاده می‌شود

### پیش‌نیازها
- PHP 8.1+
- MySQL 5.7+ (اختیاری)
- PDO Extension

## رفع مشکلات

### خطای اتصال به دیتابیس
- اطلاعات `.env` را بررسی کنید
- مطمئن شوید دیتابیس ساخته شده
- دسترسی‌های کاربر را بررسی کنید

### خطای آپلود فایل
- پوشه `public/uploads` باید writable باشد
- `upload_max_filesize` در php.ini بررسی شود
- `post_max_size` در php.ini بررسی شود

## گام‌های بعدی

### اولویت بالا
1. اتصال کامل به MySQL (تست روی هاست)
2. Email notifications برای فرم تماس
3. Anti-spam (reCAPTCHA)

### اولویت متوسط
4. Image optimization و resize
5. File manager پیشرفته
6. Bulk upload

### اولویت پایین
7. API endpoints بیشتر
8. Search functionality
9. Pagination

---

**تاریخ انتشار:** 2026-07-02  
**وضعیت:** Production Ready  
**سازگاری:** IranServer Linux5 Compatible
