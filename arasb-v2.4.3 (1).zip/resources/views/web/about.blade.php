@extends('layouts.web')

@section('content')
<section class="section-light">
    <div class="container">
        <span class="eyebrow">About Arasb</span>
        <h2>A unified premium presentation for every future page.</h2>
        <p class="lead">This page is part of the Laravel foundation and demonstrates the preserved visual system.</p>
    </div>
</section>
@endsection
