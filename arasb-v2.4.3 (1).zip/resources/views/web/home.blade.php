@extends('layouts.web')

@section('content')
<section class="ref-home exact-pass">
    <div class="ref-hero exact-hero" style="background-image:url('/assets/hero-trading.jpg');">
        <div class="ref-overlay exact-overlay"></div>

        <div class="ref-topbar exact-topbar">
            <div class="ref-container exact-topbar-row">
                <div class="exact-topbar-left">🌐&nbsp;&nbsp;GLOBAL EXPORT PARTNER &nbsp;&nbsp;&nbsp; ✉&nbsp;&nbsp;INFO@ARASBTRADING.COM</div>
                <div class="exact-topbar-right">TEHRAN, IRAN • EMEA REGION</div>
            </div>
        </div>

        <div class="ref-navbar-wrap exact-navbar-wrap">
            <div class="ref-container exact-navbar">
                <div class="exact-brand">ARASB<span>TRADING</span></div>
                <nav class="exact-nav-links">
                    <a href="#">Home</a>
                    <a href="#products">Products</a>
                    <a href="#services">Services</a>
                    <a href="#process">Process</a>
                    <a href="#contact">Contact</a>
                </nav>
                <div class="exact-nav-right">
                    <div class="exact-lang-switch">
                        <a class="active" href="/{{ $locale }}">EN</a>
                        <span>|</span>
                        <a href="/fa">FA</a>
                    </div>
                    <a class="exact-contact-btn" href="#contact">Contact Us</a>
                </div>
            </div>
        </div>

        <div class="ref-container exact-hero-content">
            <span class="exact-badge">Leading Export Partner</span>
            <h1>
                Empowering Your<br>
                Access to<br>
                <span>Premium Iranian Exports</span>
            </h1>
            <p>
                Specialized in supplying premium Iranian products to European and Arab
                markets. We manage the entire export lifecycle with precision and reliability.
            </p>
            <div class="exact-actions">
                <a class="exact-btn-primary" href="#products">Explore Products <span>→</span></a>
                <a class="exact-btn-secondary" href="#services">Our Services</a>
            </div>
        </div>

        <div class="exact-scroll-indicator">
            <span>SCROLL TO EXPLORE</span>
            <div class="exact-chevron">⌄</div>
        </div>
    </div>
</section>
@endsection
