@extends('layouts.web')

@section('content')
<section class="section-light">
    <div class="container narrow">
        <span class="eyebrow">Contact</span>
        <h2>A premium multilingual contact experience will be built here.</h2>
        <form class="contact-card" method="POST" action="/api/contact-submit">
            <input type="hidden" name="language_code" value="{{ $locale }}">
            <input type="hidden" name="source_page" value="contact">
            <input class="field" name="full_name" placeholder="Name" required>
            <input class="field" name="email" type="email" placeholder="Email" required>
            <input class="field" name="mobile" placeholder="Mobile">
            <input class="field" name="company_name" placeholder="Company">
            <input class="field" name="country" placeholder="Country">
            <input class="field" name="subject" placeholder="Subject">
            <textarea class="field" name="message" rows="6" placeholder="Message" required></textarea>
            <button class="btn-primary" type="submit">Send Request</button>
        </form>
    </div>
</section>
@endsection
