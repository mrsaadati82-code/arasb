@extends('layouts.web')

@section('content')
<section class="section-dark">
    <div class="container">
        <span class="eyebrow">Products</span>
        <h2 class="light">Export-ready product collections</h2>
        <div class="product-grid">
            <div class="product-card"><div class="product-media"></div><div class="product-body">Saffron</div></div>
            <div class="product-card"><div class="product-media"></div><div class="product-body">Pistachio</div></div>
            <div class="product-card"><div class="product-media"></div><div class="product-body">Dates</div></div>
            <div class="product-card"><div class="product-media"></div><div class="product-body">Petrochemicals</div></div>
        </div>
    </div>
</section>
@endsection
