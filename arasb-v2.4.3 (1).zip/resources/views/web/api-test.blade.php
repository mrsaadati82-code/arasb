@extends('layouts.web')

@section('content')
<section class="section-light">
    <div class="container narrow">
        <span class="eyebrow">API</span>
        <h2>API endpoints are active in this build.</h2>
        <div class="contact-card">
            <p><strong>GET</strong> /api/settings</p>
            <p><strong>GET</strong> /api/languages</p>
            <p><strong>GET</strong> /api/home-sections?locale=fa</p>
            <p><strong>GET</strong> /api/products</p>
            <p><strong>POST</strong> /api/contact-submit</p>
        </div>
    </div>
</section>
@endsection
