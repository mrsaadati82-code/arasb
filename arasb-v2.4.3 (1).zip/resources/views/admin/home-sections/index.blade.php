@extends('layouts.admin')

@section('content')
<div class="panel-stack">
    <div class="panel-head">
        <div>
            <h1>سکشن‌های صفحه اصلی</h1>
            <p class="muted">در این بخش محتوای ساختاریافته homepage برای سه زبان مدیریت می‌شود، بدون اینکه layout تاییدشده UI تغییر کند.</p>
        </div>
        <a class="admin-btn" href="/admin/home-sections/edit">افزودن سکشن</a>
    </div>
    <div class="table-card">
        <table class="data-table">
            <thead>
                <tr>
                    <th>کلید سکشن</th>
                    <th>نوع</th>
                    <th>ترتیب</th>
                    <th>وضعیت</th>
                    <th>عنوان فارسی</th>
                    <th>اقدام</th>
                </tr>
            </thead>
            <tbody>
                @foreach($items as $item)
                <tr>
                    <td>{{ $item['section_key'] }}</td>
                    <td>{{ $item['section_type'] }}</td>
                    <td>{{ $item['sort_order'] }}</td>
                    <td><span class="badge neutral">{{ $item['is_active'] }}</span></td>
                    <td>{{ $item['translations']['fa']['title'] }}</td>
                    <td><a href="/admin/home-sections/edit?id={{ $item['id'] }}">ویرایش</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
