@extends('layouts.admin')

@section('content')

<div style="margin-bottom: 24px;">
    <h1 style="margin: 0 0 8px; font-size: 22px; color: #1e293b;">📁 مدیریت رسانه</h1>
    <p style="color: #64748b; font-size: 14px; margin: 0;">آپلود و مدیریت فایل‌ها و تصاویر</p>
</div>

@if($uploadedCount)
<div style="padding: 14px 20px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0;">
    ✅ تعداد {{ $uploadedCount }} فایل با موفقیت آپلود شد.
</div>
@endif

@if($errorMsg)
<div style="padding: 14px 20px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; background: #fef2f2; color: #991b1b; border: 1px solid #fecaca;">
    ❌ خطا: {{ $errorMsg }}
</div>
@endif

<!-- Upload Form -->
<div style="background: white; border-radius: 14px; border: 1px solid #e2e8f0; margin-bottom: 24px; overflow: hidden;">
    <div style="padding: 14px 20px; border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
        <h3 style="margin: 0; font-size: 15px; color: #1e293b;">⬆️ آپلود فایل جدید</h3>
    </div>
    <div style="padding: 20px;">
        <form method="POST" action="/admin/media/upload" enctype="multipart/form-data" style="display: flex; gap: 16px; align-items: flex-end; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #334155;">انتخاب فایل (حداکثر ۱۰ مگابایت)</label>
                <input type="file" name="files[]" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" required style="width: 100%; padding: 8px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 13px;">
                <small style="display: block; margin-top: 4px; font-size: 11px; color: #94a3b8;">فرمت‌ها: JPG, PNG, GIF, WebP, PDF, DOC, XLS</small>
            </div>
            <button type="submit" style="padding: 10px 28px; background: #1e293b; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer;">آپلود</button>
        </form>
    </div>
</div>

<!-- Media Library -->
<div style="background: white; border-radius: 14px; border: 1px solid #e2e8f0; overflow: hidden;">
    <div style="padding: 14px 20px; border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
        <h3 style="margin: 0; font-size: 15px; color: #1e293b;">🗂️ کتابخانه رسانه ({{ $mediaCount }} فایل)</h3>
    </div>
    <div style="padding: 20px;">
        
        @if($mediaCount)
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px;">
            @foreach($media as $item)
            <div style="border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background: white; transition: box-shadow 0.2s;" onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,0.08)'" onmouseout="this.style.boxShadow='none'">
                <div style="width: 100%; height: 140px; display: flex; align-items: center; justify-content: center; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;">
                    <img src="{{ $item['path'] }}" alt="{{ $item['short_name'] }}" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                <div style="padding: 12px;">
                    <p style="font-weight: 600; font-size: 13px; margin: 0 0 2px; color: #1e293b; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{{ $item['original_name'] }}">{{ $item['short_name'] }}</p>
                    <p style="font-size: 11px; color: #94a3b8; margin: 0 0 8px;">{{ $item['size_formatted'] }}</p>
                    <input type="text" value="{{ $item['path'] }}" readonly onclick="this.select()" style="width: 100%; padding: 5px 8px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 11px; font-family: monospace; direction: ltr; text-align: left; box-sizing: border-box; color: #475569; background: #f8fafc;">
                </div>
                <div style="padding: 10px 12px; border-top: 1px solid #e2e8f0; display: flex; gap: 6px;">
                    <a href="{{ $item['path'] }}" target="_blank" style="flex: 1; text-align: center; padding: 5px 8px; background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 11px; text-decoration: none;">مشاهده</a>
                    <a href="/admin/media/delete?id={{ $item['id'] }}" onclick="return confirm('آیا مطمئن هستید؟')" style="flex: 1; text-align: center; padding: 5px 8px; background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; border-radius: 6px; font-size: 11px; text-decoration: none;">حذف</a>
                </div>
            </div>
            @endforeach
        </div>
        @else
        <p style="text-align: center; padding: 40px; color: #94a3b8; font-size: 14px;">هنوز فایلی آپلود نشده است.</p>
        @endif
        
    </div>
</div>

@endsection
