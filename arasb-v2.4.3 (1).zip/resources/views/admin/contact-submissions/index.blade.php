@extends('layouts.admin')

@section('content')
<div class="panel-head">
    <div>
        <h1>📬 پیام‌های تماس ({{ $totalCount ?? 0 }})</h1>
        <p class="muted">پیام‌های ثبت‌شده از فرم تماس سایت</p>
    </div>
    @if($hasItems)
    <a class="admin-btn secondary" href="/admin/contact-submissions/export">📥 خروجی CSV</a>
    @endif
</div>

@if($hasItems)
@foreach($items as $item)
<div class="panel-card">
    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:14px; flex-wrap:wrap; gap:8px;">
        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
            @if($item['status'] === 'new')
            <span class="badge warning">🆕 جدید</span>
            @else
            <span class="badge success">✓ خوانده</span>
            @endif
            <span class="badge info">{{ $item['language_code'] ?? 'en' }}</span>
        </div>
        <span style="font-size:12px; color:var(--muted); direction:ltr;">{{ $item['created_at'] ?? '' }}</span>
    </div>

    <div class="form-grid three" style="margin-bottom:14px;">
        <div>
            <span style="font-size:11px; color:var(--muted); display:block; margin-bottom:2px;">👤 نام</span>
            <strong style="font-size:13px;">{{ $item['full_name'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--muted); display:block; margin-bottom:2px;">📧 ایمیل</span>
            <a href="mailto:{{ $item['email'] ?? '' }}" style="font-size:13px; color:var(--brand); text-decoration:none;">{{ $item['email'] ?? '-' }}</a>
        </div>
        <div>
            <span style="font-size:11px; color:var(--muted); display:block; margin-bottom:2px;">📱 موبایل</span>
            <strong style="font-size:13px; direction:ltr; display:inline-block;">{{ $item['mobile'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--muted); display:block; margin-bottom:2px;">🏢 شرکت</span>
            <strong style="font-size:13px;">{{ $item['company_name'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--muted); display:block; margin-bottom:2px;">🌍 کشور</span>
            <strong style="font-size:13px;">{{ $item['country'] ?? '-' }}</strong>
        </div>
        <div>
            <span style="font-size:11px; color:var(--muted); display:block; margin-bottom:2px;">📋 موضوع</span>
            <strong style="font-size:13px;">{{ $item['subject'] ?? '-' }}</strong>
        </div>
    </div>

    <div style="background:#f8fafc; border:1px solid var(--border); border-radius:var(--radius); padding:14px; font-size:14px; line-height:1.8; margin-bottom:14px;">
        {{ $item['message'] ?? '-' }}
    </div>

    <div style="display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap;">
        <a href="mailto:{{ $item['email'] ?? '' }}" class="admin-btn primary" style="font-size:12px;">↩️ پاسخ ایمیل</a>
        @if($item['status'] === 'new')
        <a href="/admin/contact-submissions/mark-read?id={{ $item['id'] }}" class="admin-btn secondary" style="font-size:12px;">✓ خوانده شد</a>
        @endif
        <a href="/admin/contact-submissions/delete?id={{ $item['id'] }}" class="admin-btn secondary" style="font-size:12px; color:var(--red);" onclick="return confirm('حذف این پیام؟')">🗑 حذف</a>
    </div>
</div>
@endforeach
@else
<div class="panel-card">
    <div class="empty-state">
        <div class="empty-icon">📭</div>
        <p>هنوز پیامی دریافت نشده است.</p>
    </div>
</div>
@endif
@endsection
