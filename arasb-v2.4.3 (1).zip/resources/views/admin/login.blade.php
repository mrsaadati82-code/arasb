@extends('layouts.admin')

@section('content')
<div style="max-width:420px; margin:60px auto 0;">
    <div class="panel-card" style="text-align:center; padding:40px 32px;">
        <div style="font-size:48px; margin-bottom:16px;">🔐</div>
        <h1 style="font-size:22px; font-weight:800; margin-bottom:8px;">ورود به پنل مدیریت</h1>
        <p style="color:var(--text-muted); font-size:14px; margin-bottom:28px;">برای مشاهده بخش‌های مدیریتی وارد شوید</p>

        @if($error ?? '')
        <div class="notice error" style="text-align:right;">❌ {{ $error }}</div>
        @endif

        <form method="POST" action="/admin/login" class="form-stack" style="text-align:right;">
            <div>
                <label class="field-label">ایمیل</label>
                <input class="field" name="email" placeholder="admin@arasb.local" value="{{ $email ?? 'admin@arasb.local' }}">
            </div>
            <div>
                <label class="field-label">رمز عبور</label>
                <input class="field" name="password" placeholder="••••••" type="password">
            </div>
            <button class="admin-btn primary" type="submit" style="width:100%; justify-content:center; padding:12px; font-size:15px;">ورود</button>
        </form>
    </div>
</div>
@endsection
