@extends('layouts.admin')

@section('content')
<div class="panel-stack">
    <div class="panel-head sticky-head">
        <div>
            <h1>ویرایش صفحه</h1>
            <p class="muted">مدیریت عنوان، وضعیت، ترجمه‌ها و سئوی صفحه</p>
        </div>
        <div class="head-actions">
            <a class="admin-btn ghost" href="/admin/pages">بازگشت</a>
        </div>
    </div>

    @if($saved ?? 0)
    <div class="notice success-notice">اطلاعات صفحه با موفقیت در فایل داده ذخیره شد.</div>
    @endif

    <form method="POST" action="/admin/pages/save" class="editor-grid">
        <input type="hidden" name="id" value="{{ $item['id'] }}">
        <div class="panel-card">
            <h3>اطلاعات پایه</h3>
            <div class="form-grid">
                <input class="field" name="title" placeholder="عنوان صفحه" value="{{ $item['title'] }}">
                <input class="field" name="type" placeholder="نوع" value="{{ $item['type'] }}">
                <input class="field" name="status" placeholder="وضعیت" value="{{ $item['status'] }}">
                <input class="field" name="translations" placeholder="ترجمه‌ها" value="{{ $item['translations'] }}">
            </div>
        </div>

        <div class="panel-card">
            <h3>زبان‌ها</h3>
            <div class="lang-tabs">
                <span class="lang-tab active">فارسی</span>
                <span class="lang-tab">English</span>
                <span class="lang-tab">العربية</span>
            </div>
            <div class="form-grid">
                <textarea class="field" rows="8" placeholder="محتوا"></textarea>
            </div>
        </div>

        <div><button class="admin-btn" type="submit" style="border:0;">ذخیره صفحه</button></div>
    </form>
</div>
@endsection
