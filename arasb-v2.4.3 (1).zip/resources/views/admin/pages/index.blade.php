@extends('layouts.admin')

@section('content')
<div class="panel-stack">
    <div class="panel-head">
        <div>
            <h1>مدیریت صفحات</h1>
            <p class="muted">پایه CMS صفحات در این بخش توسعه پیدا می‌کند.</p>
        </div>
        <a class="admin-btn" href="/admin/pages/edit">افزودن صفحه</a>
    </div>
    <div class="table-card">
        <table class="data-table">
            <thead>
                <tr>
                    <th>عنوان</th>
                    <th>نوع</th>
                    <th>وضعیت</th>
                    <th>ترجمه‌ها</th>
                    <th>اقدام</th>
                </tr>
            </thead>
            <tbody>
                @foreach($items as $item)
                <tr>
                    <td>{{ $item['title'] }}</td>
                    <td>{{ $item['type'] }}</td>
                    <td><span class="badge neutral">{{ $item['status'] }}</span></td>
                    <td>{{ $item['translations'] }}</td>
                    <td><a href="/admin/pages/edit?id={{ $item['id'] }}">ویرایش</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
