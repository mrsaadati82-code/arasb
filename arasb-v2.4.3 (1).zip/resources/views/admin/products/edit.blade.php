@extends('layouts.admin')

@section('content')
<div class="panel-head">
    <div>
        <h1>{{ $title }}</h1>
        <p class="muted">مدیریت اطلاعات، ترجمه‌ها و تصویر محصول</p>
    </div>
    <a class="admin-btn secondary" href="/admin/products">↩️ بازگشت</a>
</div>

@if($saved)
<div class="notice success">✅ اطلاعات محصول با موفقیت ذخیره شد.</div>
@endif

<form method="POST" action="/admin/products/save" class="form-stack">
    <input type="hidden" name="id" value="{{ $item['id'] }}">

    <div class="panel-card">
        <h3>📋 اطلاعات پایه</h3>
        <div class="form-grid two">
            <div>
                <label class="field-label">اسلاگ (slug)</label>
                <input class="field" name="slug" placeholder="premium-saffron" value="{{ $item['slug'] ?? '' }}">
            </div>
            <div>
                <label class="field-label">تصویر (مسیر)</label>
                <input class="field" name="image" placeholder="/saffron.jpg" value="{{ $item['image'] ?? '' }}">
            </div>
            <div>
                <label class="field-label">وضعیت</label>
                <select class="field" name="status">
                    <option value="published">منتشرشده</option>
                    <option value="draft">پیش‌نویس</option>
                </select>
            </div>
            <div>
                <label class="field-label">ترتیب نمایش</label>
                <input class="field" name="sort_order" type="number" value="{{ $item['sort_order'] ?? '0' }}">
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🏷️ دسته‌بندی (هر زبان)</h3>
        <div class="form-grid three">
            <div>
                <label class="field-label">🇬🇧 English</label>
                <input class="field" name="category_en" placeholder="Category" value="{{ $item['category']['en'] ?? '' }}">
            </div>
            <div>
                <label class="field-label">🇮🇷 فارسی</label>
                <input class="field" name="category_fa" placeholder="دسته‌بندی" value="{{ $item['category']['fa'] ?? '' }}">
            </div>
            <div>
                <label class="field-label">🇸🇦 العربية</label>
                <input class="field" name="category_ar" placeholder="فئة" value="{{ $item['category']['ar'] ?? '' }}">
            </div>
        </div>
    </div>

    <div class="panel-card">
        <h3>🌐 ترجمه‌ها</h3>
        <div class="lang-block">
            <h3>🇬🇧 English</h3>
            <div class="form-grid">
                <input class="field" name="title_en" placeholder="Product title" value="{{ $item['translations']['en']['title'] ?? '' }}">
                <textarea class="field" name="description_en" rows="3" placeholder="Description">{{ $item['translations']['en']['description'] ?? '' }}</textarea>
            </div>
        </div>
        <div class="lang-block" style="margin-top:16px;">
            <h3>🇮🇷 فارسی</h3>
            <div class="form-grid">
                <input class="field" name="title_fa" placeholder="نام محصول" value="{{ $item['translations']['fa']['title'] ?? '' }}">
                <textarea class="field" name="description_fa" rows="3" placeholder="توضیحات">{{ $item['translations']['fa']['description'] ?? '' }}</textarea>
            </div>
        </div>
        <div class="lang-block" style="margin-top:16px;">
            <h3>🇸🇦 العربية</h3>
            <div class="form-grid">
                <input class="field" name="title_ar" placeholder="اسم المنت" value="{{ $item['translations']['ar']['title'] ?? '' }}">
                <textarea class="field" name="description_ar" rows="3" placeholder="الوصف">{{ $item['translations']['ar']['description'] ?? '' }}</textarea>
            </div>
        </div>
    </div>

    <div class="actions-row">
        <button class="admin-btn primary" type="submit">💾 ذخیره محصول</button>
    </div>
</form>
@endsection
