@extends('layouts.admin')

@section('content')
<div class="panel-head">
    <div>
        <h1>📦 مدیریت محصولات</h1>
        <p class="muted">محصولات صادراتی، ترجمه‌ها و وضعیت انتشار</p>
    </div>
    <a class="admin-btn primary" href="/admin/products/edit">➕ محصول جدید</a>
</div>

<div class="panel-card table-card">
    <table class="data-table">
        <thead>
            <tr>
                <th>محصول (EN)</th>
                <th>محصول (FA)</th>
                <th>دسته‌بندی</th>
                <th>وضعیت</th>
                <th>اقدام</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
            <tr>
                <td><strong>{{ $item['translations']['en']['title'] ?? '' }}</strong></td>
                <td>{{ $item['translations']['fa']['title'] ?? '' }}</td>
                <td>{{ $item['category']['fa'] ?? '' }}</td>
                <td>
                    @if($item['status'] === 'published')
                    <span class="badge success">منتشرشده</span>
                    @else
                    <span class="badge warning">پیش‌نویس</span>
                    @endif
                </td>
                <td>
                    <a class="admin-btn secondary" href="/admin/products/edit?id={{ $item['id'] }}" style="padding:6px 14px; font-size:12px;">✏️ ویرایش</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
