@extends('layouts.admin')

@section('content')

<div class="panel-head">
    <div>
        <h1>📊 داشبورد</h1>
        <p class="muted">خلاصه وضعیت سایت و دسترسی سریع</p>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">📦</div>
        <div class="stat-value">{{ $productCount ?? 0 }}</div>
        <div class="stat-label">محصولات فعال</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📬</div>
        <div class="stat-value">{{ $newMessages ?? 0 }}</div>
        <div class="stat-label">پیام‌های جدید</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📄</div>
        <div class="stat-value">{{ $pagesCount ?? 0 }}</div>
        <div class="stat-label">صفحات</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">📁</div>
        <div class="stat-value">{{ $mediaCount ?? 0 }}</div>
        <div class="stat-label">فایل‌های رسانه</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🌐</div>
        <div class="stat-value">{{ $activeLanguages ?? 3 }}</div>
        <div class="stat-label">زبان‌های فعال</div>
    </div>
</div>

<!-- Quick Links -->
<div class="panel-card">
    <h3>⚡ دسترسی سریع</h3>
    <div class="quick-links">
        <a class="quick-link" href="/admin/products">
            <div class="ql-icon">📦</div>
            <div class="ql-text">
                <span class="ql-title">محصولات</span>
                <span class="ql-sub">مدیریت محصولات و ترجمه‌ها</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/home-sections">
            <div class="ql-icon">🏠</div>
            <div class="ql-text">
                <span class="ql-title">سکشن‌های صفحه اصلی</span>
                <span class="ql-sub">ویرایش محتوای صفحه اصلی</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/media">
            <div class="ql-icon">📁</div>
            <div class="ql-text">
                <span class="ql-title">رسانه</span>
                <span class="ql-sub">آپلود و مدیریت فایل‌ها</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/pages">
            <div class="ql-icon">📄</div>
            <div class="ql-text">
                <span class="ql-title">صفحات</span>
                <span class="ql-sub">مدیریت صفحات سایت</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/contact-submissions">
            <div class="ql-icon">📬</div>
            <div class="ql-text">
                <span class="ql-title">پیام‌های تماس</span>
                <span class="ql-sub">مشاهده و مدیریت پیام‌ها</span>
            </div>
        </a>
        <a class="quick-link" href="/admin/settings">
            <div class="ql-icon">⚙️</div>
            <div class="ql-text">
                <span class="ql-title">تنظیمات</span>
                <span class="ql-sub">عمومی، SMTP و ظاهر</span>
            </div>
        </a>
    </div>
</div>

@endsection
