@extends('layouts.admin')

@section('content')
<div class="panel-stack">
    <div class="panel-card">
        <h1>مدیریت زبان‌ها</h1>
        <p class="muted">در این بخش وضعیت زبان‌های فارسی، انگلیسی و عربی و کامل‌بودن ترجمه‌ها مدیریت می‌شود.</p>
    </div>
    <div class="table-card">
        <table class="data-table">
            <thead>
                <tr>
                    <th>زبان</th>
                    <th>کد</th>
                    <th>جهت</th>
                    <th>وضعیت</th>
                    <th>پیش‌فرض</th>
                </tr>
            </thead>
            <tbody>
                @foreach($items as $item)
                <tr>
                    <td>{{ $item['native_name'] }}</td>
                    <td>{{ $item['code'] }}</td>
                    <td>{{ $item['direction'] }}</td>
                    <td><span class="badge success">{{ $item['is_active'] }}</span></td>
                    <td><span class="badge warning">{{ $item['is_default'] }}</span></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
