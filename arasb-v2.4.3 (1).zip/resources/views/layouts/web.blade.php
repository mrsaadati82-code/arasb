<!DOCTYPE html>
<html lang="{{ $locale ?? 'fa' }}" dir="{{ $dir ?? 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'ARASB' }}</title>
    <link rel="stylesheet" href="/assets/css/site.css">
</head>
<body class="site-body">
    <main>
        @yield('content')
    </main>
</body>
</html>
