# راهنمای نصب ARASB v2.1.0

## پیش‌نیازها
- PHP 8.1 یا بالاتر
- MySQL 5.7 یا بالاتر
- هاست با پشتیبانی از mod_rewrite (اختیاری)

## مراحل نصب

### 1. آپلود فایل‌ها
تمام فایل‌های موجود در این بسته را در پوشه `public_html` یا `httpdocs` هاست خود آپلود کنید.

**مهم:** Document Root باید روی پوشه اصلی باشد (نه پوشه `public`).

### 2. تنظیم دیتابیس
فایل `.env` را ویرایش کنید و اطلاعات دیتابیس خود را وارد کنید:

```env
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=arasb_db
DB_USERNAME=your_db_username
DB_PASSWORD=your_db_password
```

### 3. اجرای نصب‌کننده
دو روش برای اجرای نصب‌کننده وجود دارد:

#### روش اول: از طریق مرورگر
به آدرس زیر بروید:
```
https://yourdomain.com/install.php
```

#### روش دوم: از طریق SSH
```bash
cd public_html
php install.php
```

### 4. بررسی نصب
پس از اتمام نصب، باید پیام‌های موفقیت را ببینید:
- ✓ Database created/verified
- ✓ Migration OK: 001_create_languages_table.php
- ✓ Migration OK: 002_create_settings_table.php
- ✓ ... (تمام migration ها)
- ✓ Settings seeded
- ✓ Languages seeded
- ✓ Pages seeded
- ✓ Products seeded
- ✓ Home sections seeded
- ✓ Admin user created

### 5. حذف فایل نصب
**بسیار مهم:** پس از نصب موفق، فایل `install.php` را حذف کنید:

```bash
rm install.php
```

### 6. ورود به پنل مدیریت
- آدرس: `https://yourdomain.com/admin/login`
- نام کاربری: `admin`
- رمز عبور: `admin123`

**توجه:** بلافاصله پس از اولین ورود، رمز عبور را تغییر دهید.

## ساختار فایل‌ها

```
/
├── .env                    # تنظیمات دیتابیس
├── .htaccess              # قوانین rewrite
├── install.php            # نصب‌کننده (پس از نصب حذف کنید)
├── index.html             # فرانت React
├── admin/
│   └── index.php         # پنل مدیریت
├── api/
│   └── index.php         # API عمومی
├── assets/               # CSS، فونت‌ها، تصاویر
├── app/                  # کدهای PHP
├── database/
│   └── migrations/       # ساختار جداول
├── resources/
│   └── views/           # قالب‌های Blade
└── storage/
    └── data/            # فایل‌های JSON (backup)
```

## آدرس‌های مهم

### سایت عمومی
- صفحه اصلی: `/`
- فارسی: `/fa`
- انگلیسی: `/en`
- عربی: `/ar`

### پنل مدیریت
- ورود: `/admin/login`
- داشبورد: `/admin`
- تنظیمات: `/admin/settings`
- صفحات: `/admin/pages`
- محصولات: `/admin/products`
- سکشن‌های اصلی: `/admin/home-sections`
- پیام‌های تماس: `/admin/contact-submissions`

### API
- تنظیمات: `/api/settings`
- زبان‌ها: `/api/languages`
- سکشن‌های اصلی: `/api/home-sections?locale=fa`
- محصولات: `/api/products`
- ارسال تماس: `POST /api/contact-submit`

## رفع مشکلات

### خطای اتصال به دیتابیس
1. بررسی کنید اطلاعات `.env` صحیح باشد
2. مطمئن شوید دیتابیس ساخته شده است
3. دسترسی‌های کاربر دیتابیس را بررسی کنید

### خطای 500
1. فایل `install.php` را اجرا کنید
2. لاگ‌های PHP را بررسی کنید
3. مطمئن شوید PHP 8.1+ نصب است

### پنل مدیریت کار نمی‌کند
1. فایل `install.php` را اجرا کنید
2. مطمئن شوید migration ها اجرا شده‌اند
3. فایل `.env` را بررسی کنید

## ویژگی‌های جدید در v2.1.0

### ✓ پشتیبانی از MySQL
- اتصال به دیتابیس واقعی
- Migration های خودکار
- Seed داده‌های اولیه

### ✓ Fallback هوشمند
- اگر MySQL در دسترس نباشد، از JSON استفاده می‌شود
- هیچ داده‌ای از دست نمی‌رود

### ✓ نصب‌کننده خودکار
- ایجاد دیتابیس
- اجرای migration ها
- Seed داده‌ها
- ایجاد کاربر admin

### ✓ Media Manager (جدید)
- آپلود فایل
- مدیریت تصاویر
- Gallery محصولات

## پشتیبانی
برای گزارش مشکلات و پیشنهادات، لطفاً از GitHub Issues استفاده کنید.

---

**نسخه:** 2.1.0  
**تاریخ:** 2026-07-02  
**وضعیت:** Production Ready
