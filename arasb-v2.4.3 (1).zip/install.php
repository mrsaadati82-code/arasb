<?php

/**
 * ARASB Database Installer
 * 
 * This script:
 * 1. Reads .env file for database credentials
 * 2. Creates database if needed
 * 3. Runs all migrations
 * 4. Seeds initial data from JSON files
 * 
 * Run once after uploading to your host:
 *   php install.php
 * Or visit: https://yourdomain.com/install.php
 */

// Load .env
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        if (str_contains($line, '=')) {
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            putenv("{$key}={$value}");
            $_ENV[$key] = $value;
        }
    }
}

$host = getenv('DB_HOST') ?: 'localhost';
$port = getenv('DB_PORT') ?: '3306';
$database = getenv('DB_DATABASE') ?: 'arasb_db';
$username = getenv('DB_USERNAME') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';

$output = [];
$errors = [];
$success = true;

function log_msg(string $msg, string $type = 'info'): void
{
    global $output;
    $output[] = ['type' => $type, 'msg' => $msg];
}

try {
    // Connect without database
    $pdo = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    log_msg("Database '{$database}' created/verified.", 'success');

    $pdo->exec("USE `{$database}`");

    // Run migrations
    $migrationDir = __DIR__ . '/database/migrations';
    $files = glob($migrationDir . '/*.php');
    sort($files);

    foreach ($files as $file) {
        $basename = basename($file);
        try {
            $sql = require $file;
            if (is_string($sql)) {
                $pdo->exec($sql);
            } elseif (is_array($sql)) {
                foreach ($sql as $statement) {
                    if (is_string($statement) && trim($statement) !== '') {
                        $pdo->exec($statement);
                    }
                }
            }
            log_msg("Migration OK: {$basename}", 'success');
        } catch (Exception $e) {
            if (str_contains($e->getMessage(), 'already exists') || str_contains($e->getMessage(), 'Duplicate')) {
                log_msg("Migration skipped (already exists): {$basename}", 'warning');
            } else {
                log_msg("Migration error in {$basename}: " . $e->getMessage(), 'error');
                $errors[] = $basename;
            }
        }
    }

    // Seed from JSON files
    $dataDir = __DIR__ . '/storage/data';

    // Seed settings
    if (file_exists("{$dataDir}/settings.json")) {
        $settings = json_decode(file_get_contents("{$dataDir}/settings.json"), true);
        if (is_array($settings)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM settings");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $insertStmt = $pdo->prepare("INSERT INTO settings (group_key, setting_key, label, value) VALUES (?, ?, ?, ?)");
                foreach ($settings as $s) {
                    try {
                        $insertStmt->execute([
                            $s['group_key'] ?? '',
                            $s['setting_key'] ?? '',
                            $s['label'] ?? '',
                            $s['value'] ?? '',
                        ]);
                    } catch (Exception $e) {
                        // Ignore duplicates
                    }
                }
                log_msg("Settings seeded (" . count($settings) . " items).", 'success');
            } else {
                log_msg("Settings already seeded, skipped.", 'warning');
            }
        }
    }

    // Seed languages
    if (file_exists("{$dataDir}/languages.json")) {
        $languages = json_decode(file_get_contents("{$dataDir}/languages.json"), true);
        if (is_array($languages)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM languages");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $insertStmt = $pdo->prepare("INSERT INTO languages (code, name, native_name, direction, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
                foreach ($languages as $lang) {
                    try {
                        $insertStmt->execute([
                            $lang['code'] ?? '',
                            $lang['name'] ?? '',
                            $lang['native_name'] ?? '',
                            $lang['direction'] ?? 'ltr',
                            $lang['is_active'] ?? 1,
                            $lang['sort_order'] ?? 0,
                        ]);
                    } catch (Exception $e) {
                        // Ignore duplicates
                    }
                }
                log_msg("Languages seeded (" . count($languages) . " items).", 'success');
            } else {
                log_msg("Languages already seeded, skipped.", 'warning');
            }
        }
    }

    // Seed pages
    if (file_exists("{$dataDir}/pages.json")) {
        $pages = json_decode(file_get_contents("{$dataDir}/pages.json"), true);
        if (is_array($pages)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM pages");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $insertStmt = $pdo->prepare("INSERT INTO pages (slug, status, sort_order, translations) VALUES (?, ?, ?, ?)");
                foreach ($pages as $page) {
                    try {
                        $insertStmt->execute([
                            $page['slug'] ?? '',
                            $page['status'] ?? 'published',
                            $page['sort_order'] ?? 0,
                            json_encode($page['translations'] ?? [], JSON_UNESCAPED_UNICODE),
                        ]);
                    } catch (Exception $e) {
                        // Ignore duplicates
                    }
                }
                log_msg("Pages seeded (" . count($pages) . " items).", 'success');
            } else {
                log_msg("Pages already seeded, skipped.", 'warning');
            }
        }
    }

    // Seed products
    if (file_exists("{$dataDir}/products.json")) {
        $products = json_decode(file_get_contents("{$dataDir}/products.json"), true);
        if (is_array($products)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM products");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $insertStmt = $pdo->prepare("INSERT INTO products (slug, image, status, sort_order, category, translations) VALUES (?, ?, ?, ?, ?, ?)");
                foreach ($products as $product) {
                    try {
                        $insertStmt->execute([
                            $product['slug'] ?? '',
                            $product['image'] ?? '',
                            $product['status'] ?? 'published',
                            $product['sort_order'] ?? 0,
                            json_encode($product['category'] ?? '', JSON_UNESCAPED_UNICODE),
                            json_encode($product['translations'] ?? [], JSON_UNESCAPED_UNICODE),
                        ]);
                    } catch (Exception $e) {
                        // Ignore duplicates
                    }
                }
                log_msg("Products seeded (" . count($products) . " items).", 'success');
            } else {
                log_msg("Products already seeded, skipped.", 'warning');
            }
        }
    }

    // Seed home sections
    if (file_exists("{$dataDir}/home_sections.json")) {
        $sections = json_decode(file_get_contents("{$dataDir}/home_sections.json"), true);
        if (is_array($sections)) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM home_sections");
            $stmt->execute();
            if ($stmt->fetchColumn() == 0) {
                $insertStmt = $pdo->prepare("INSERT INTO home_sections (page_key, section_key, section_type, is_active, sort_order, translations) VALUES (?, ?, ?, ?, ?, ?)");
                foreach ($sections as $section) {
                    try {
                        $insertStmt->execute([
                            $section['page_key'] ?? 'home',
                            $section['section_key'] ?? '',
                            $section['section_type'] ?? 'content',
                            $section['is_active'] ?? 1,
                            $section['sort_order'] ?? 0,
                            json_encode($section['translations'] ?? [], JSON_UNESCAPED_UNICODE),
                        ]);
                    } catch (Exception $e) {
                        // Ignore duplicates
                    }
                }
                log_msg("Home sections seeded (" . count($sections) . " items).", 'success');
            } else {
                log_msg("Home sections already seeded, skipped.", 'warning');
            }
        }
    }

    // Create admin user if not exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $passwordHash = password_hash('admin123', PASSWORD_BCRYPT);
        $pdo->exec("INSERT INTO users (username, email, password, name, role, is_active, created_at) VALUES ('admin', 'admin@arasbtrading.com', '{$passwordHash}', 'مدیر سیستم', 'super_admin', 1, NOW())");
        log_msg("Admin user created (username: admin, password: admin123)", 'success');
    } else {
        log_msg("Admin user already exists, skipped.", 'warning');
    }

    log_msg("Installation complete! You can now delete this file (install.php).", 'success');

} catch (Exception $e) {
    $success = false;
    log_msg("Installation error: " . $e->getMessage(), 'error');
}

// Output
if (php_sapi_name() === 'cli') {
    echo "\n=== ARASB Database Installer ===\n\n";
    foreach ($output as $item) {
        $prefix = match($item['type']) {
            'success' => '✓',
            'warning' => '⚠',
            'error'   => '✗',
            default   => '•',
        };
        echo "{$prefix} {$item['msg']}\n";
    }
    echo "\n";
} else {
    http_response_code($success ? 200 : 500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><title>ARASB Install</title>';
    echo '<style>body{font-family:Tahoma,sans-serif;background:#f8fafc;padding:40px;max-width:700px;margin:0 auto}';
    echo 'h1{color:#1e293b}.msg{padding:8px 16px;margin:4px 0;border-radius:8px;font-size:14px}';
    echo '.success{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0}';
    echo '.warning{background:#fffbeb;color:#92400e;border:1px solid #fde68a}';
    echo '.error{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}';
    echo '.info{background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe}</style></head><body>';
    echo '<h1>🔧 نصب‌کننده ARASB</h1>';
    foreach ($output as $item) {
        echo "<div class='msg {$item['type']}'>{$item['msg']}</div>";
    }
    echo '</body></html>';
}
