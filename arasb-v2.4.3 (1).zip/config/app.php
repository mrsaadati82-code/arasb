<?php

return [
    'name' => env('APP_NAME', 'ARASB'),
    'env' => env('APP_ENV', 'production'),
    'debug' => env('APP_DEBUG', false),
    'url' => env('APP_URL', 'http://localhost'),
    'locales' => ['fa', 'en', 'ar'],
    'fallback_locale' => 'en',
    'admin_locale' => 'fa',
];
