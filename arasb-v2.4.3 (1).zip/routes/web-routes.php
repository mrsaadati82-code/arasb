<?php

use App\Http\Controllers\Web\PageController;

return [
    ['GET', '/{locale}', [PageController::class, 'home']],
    ['GET', '/{locale}/about', [PageController::class, 'about']],
    ['GET', '/{locale}/products', [PageController::class, 'products']],
    ['GET', '/{locale}/contact', [PageController::class, 'contact']],
];
