<?php

return [
    'locales' => ['fa', 'en', 'ar'],
];
