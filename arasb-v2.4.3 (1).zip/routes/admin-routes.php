<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\LanguagesController;
use App\Http\Controllers\Admin\PagesController;
use App\Http\Controllers\Admin\ProductsController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Auth\AdminLoginController;

return [
    ['GET', '/admin', [DashboardController::class, 'index']],
    ['GET', '/admin/login', [AdminLoginController::class, 'showLogin']],
    ['POST', '/admin/login', [AdminLoginController::class, 'login']],
    ['POST', '/admin/logout', [AdminLoginController::class, 'logout']],
    ['GET', '/admin/settings', [SettingsController::class, 'index']],
    ['GET', '/admin/languages', [LanguagesController::class, 'index']],
    ['GET', '/admin/pages', [PagesController::class, 'index']],
    ['GET', '/admin/products', [ProductsController::class, 'index']],
];
