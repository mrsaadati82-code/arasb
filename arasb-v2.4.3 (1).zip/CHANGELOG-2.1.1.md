# تغییرات نسخه 2.1.1

## 🚨 رفع باگ بحرانی

### مشکل گزارش شده:
```
Cannot assign string to property App\Support\DataStore::$db of type ?object
```

### علت:
- پیاده‌سازی MySQL integration دارای خطای type checking بود
- PHP 8.1+ strict type checking باعث crash می‌شد
- فایل DataStore.php قدیمی روی هاست کش شده بود

### راه‌حل:
**بازگشت به نسخه ساده و پایدار JSON-only**

## ✅ تغییرات اعمال شده

### DataStore.php - نسخه ساده و پایدار
```php
class DataStore
{
    public static function read(string $name): array
    {
        $path = dirname(__DIR__, 2) . '/storage/data/' . $name . '.json';
        if (!file_exists($path)) {
            return [];
        }

        $json = file_get_contents($path);
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }

    public static function write(string $name, array $data): bool
    {
        $path = dirname(__DIR__, 2) . '/storage/data/' . $name . '.json';
        return (bool) file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public static function findById(string $name, int $id): ?array
    {
        $items = self::read($name);
        foreach ($items as $item) {
            if ((int)($item['id'] ?? 0) === $id) {
                return $item;
            }
        }
        return null;
    }
}
```

### ویژگی‌های این نسخه:
- ✅ بدون هیچ dependency به MySQL
- ✅ بدون property type checking
- ✅ سازگار با تمام نسخه‌های PHP 7.4+
- ✅ بدون خطای OPcache
- ✅ ساده، سریع، قابل اعتماد

## 📊 وضعیت MySQL Integration

### در این نسخه:
- ❌ غیرفعال شده (موقتاً)
- ✅ فایل‌های Database.php و install.php حفظ شده‌اند
- ⏳ در نسخه‌های آینده با تست کامل اضافه خواهد شد

### دلیل:
MySQL integration نیاز به تست بیشتر روی هاست‌های مختلف دارد. فعلاً JSON storage پایدارتر است.

## 🎯 Hero Section Bug Fix

### اصلاحات:
- ✅ HomeSectionsController - هر فیلد مستقل است
- ✅ edit.blade.php - نام فیلدها صحیح است
- ✅ ساختار: badge, title, subtitle, description

### فیلدهای صحیح:
```
Badge:       "شریک صادراتی پیشرو"
Title:       "دسترسی شما را توانمند می‌سازیم به"
Subtitle:    "صادرات ممتاز ایرانی"
Description: "متخصص در تأمین محصولات ممتاز ایرانی..."
```

## 📁 Media Manager

### ویژگی‌ها:
- ✅ آپلود فایل‌ها (حداکثر 10MB)
- ✅ پشتیبانی از: JPG, PNG, GIF, WebP, PDF, DOC, XLS
- ✅ Grid view برای تصاویر
- ✅ کپی path با یک کلیک
- ✅ حذف فایل

### Routes:
```
GET  /admin/media           - لیست فایل‌ها
POST /admin/media/upload    - آپلود فایل
GET  /admin/media/delete    - حذف فایل
```

## 📦 فایل‌های تغییر یافته

### اصلی:
1. `app/Support/DataStore.php` - ساده‌سازی کامل
2. `app/Http/Controllers/Admin/HomeSectionsController.php` - رفع باگ Hero
3. `resources/views/admin/home-sections/edit.blade.php` - اصلاح فرم
4. `storage/data/home_sections.json` - ساختار صحیح

### جدید:
- `app/Support/Database.php` - آماده برای آینده
- `app/Support/MediaManager.php` - Media Manager
- `app/Http/Controllers/Admin/MediaController.php`
- `resources/views/admin/media/index.blade.php`
- `install.php` - نصب‌کننده (برای آینده)
- `config/database.php` - تنظیمات (برای آینده)

## 🧪 تست‌های انجام شده

### ✅ تست شده:
- پنل مدیریت - بدون خطا
- Hero section editing - بدون بهم ریختگی
- Media Manager - آپلود و حذف
- تمام Admin routes - کار می‌کنند
- تمام API endpoints - کار می‌کنند
- UI عمومی - بدون تغییر

### ⏳ نیاز به تست:
- MySQL integration (در آینده)
- تست روی هاست‌های مختلف
- Performance testing

## 🚀 نحوه آپدیت

### اگر از 2.1.0 آپدیت می‌کنید:
1. **فقط این فایل‌ها را جایگزین کنید:**
   - `app/Support/DataStore.php`
   - `app/Http/Controllers/Admin/HomeSectionsController.php`
   - `resources/views/admin/home-sections/edit.blade.php`
   - `storage/data/home_sections.json`

2. **یا تمام فایل‌ها را آپلود کنید** (توصیه می‌شود)

3. **OPcache را پاک کنید:**
   ```bash
   # اگر دسترسی SSH دارید:
   php -r "opcache_reset();"
   
   # یا از طریق هاست:
   # PHP Settings → OPcache → Clear Cache
   ```

### اگر نصب تازه است:
1. تمام فایل‌ها را آپلود کنید
2. وارد `/admin/login` شوید
3. کاربری: `admin` | رمز: `admin123`

## 🔧 رفع مشکلات

### اگر هنوز خطا می‌دهد:

**1. OPcache را پاک کنید:**
```bash
php -r "opcache_reset();"
```

**2. مرورگر cache را پاک کنید:**
- Ctrl+Shift+Delete (Windows)
- Cmd+Shift+Delete (Mac)

**3. مطمئن شوید فایل‌ها آپلود شده‌اند:**
```bash
# بررسی کنید DataStore.php جدید است:
grep -c "useDatabase" app/Support/DataStore.php
# باید 0 باشد (یعنی فایل قدیمی نیست)
```

**4. PHP version را بررسی کنید:**
- باید PHP 7.4 یا بالاتر باشد

## 📝 یادداشت‌های مهم

### چرا MySQL غیرفعال شد؟
1. **پایداری:** JSON storage سال‌هاست کار می‌کند
2. **سازگاری:** با تمام هاست‌ها کار می‌کند
3. **سادگی:** بدون نیاز به setup دیتابیس
4. **سرعت:** برای حجم داده فعلی کافی است

### آیا MySQL اضافه خواهد شد؟
بله، اما:
- بعد از تست کامل روی هاست‌های مختلف
- با migration tool بهتر
- با fallback قوی‌تر
- در نسخه 2.2.0 یا 3.0.0

## ✨ جمع‌بندی

**نسخه 2.1.1 = پایدار + Media Manager + Hero Fix**

- ✅ بدون خطای DataStore
- ✅ Media Manager فعال
- ✅ Hero section درست کار می‌کند
- ✅ تمام قابلیت‌های قبلی حفظ شده
- ✅ آماده برای production

---

**تاریخ انتشار:** 2026-07-02  
**وضعیت:** ✅ Production Ready  
**سازگاری:** PHP 7.4+, تمام هاست‌ها  
**نسخه:** 2.1.1
