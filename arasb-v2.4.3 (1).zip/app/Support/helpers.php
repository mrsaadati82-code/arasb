<?php

function arasb_view(string $view, array $data = []): void
{
    $viewPath = dirname(__DIR__, 2) . '/resources/views/' . str_replace('.', '/', $view) . '.blade.php';

    if (!file_exists($viewPath)) {
        http_response_code(404);
        echo 'View not found: ' . htmlspecialchars($view);
        return;
    }

    if (str_starts_with($view, 'admin.')) {
        $data = array_merge(arasb_admin_layout_data(), $data);
    }

    $original = file_get_contents($viewPath);
    preg_match('/@extends\(\'layouts\.([a-zA-Z0-9_-]+)\'\)/', $original, $layoutMatch);
    preg_match('/@section\(\'content\'\)(.*?)@endsection/s', $original, $sectionMatch);
    $sectionHtml = $sectionMatch[1] ?? $original;
    $sectionHtml = arasb_render_bladeish($sectionHtml, $data);

    if (!empty($layoutMatch[1])) {
        $layoutPath = dirname(__DIR__, 2) . '/resources/views/layouts/' . $layoutMatch[1] . '.blade.php';
        $layoutContent = file_exists($layoutPath) ? file_get_contents($layoutPath) : "@yield('content')";
        $layoutContent = str_replace("@yield('content')", $sectionHtml, $layoutContent);
        echo arasb_render_bladeish($layoutContent, $data);
        return;
    }

    echo $sectionHtml;
}

function arasb_admin_layout_data(): array
{
    require_once dirname(__DIR__) . '/Support/DataStore.php';

    $settings = [];
    foreach (\App\Support\DataStore::read('settings') as $item) {
        $settings[$item['setting_key']] = $item['value'] ?? '';
    }
    $font = $settings['font_family'] ?? 'default';

    $currentPath = $_SERVER['REQUEST_URI'] ?? '';

    $newMessageCount = 0;
    foreach (\App\Support\DataStore::read('contact_submissions') as $s) {
        if (($s['status'] ?? '') === 'new') {
            $newMessageCount++;
        }
    }

    $navItems = [
        ['url' => '/admin', 'icon' => '📊', 'label' => 'داشبورد', 'match' => '/admin', 'badgeHtml' => ''],
        ['url' => '/admin/pages', 'icon' => '📄', 'label' => 'صفحات', 'match' => '/admin/pages', 'badgeHtml' => ''],
        ['url' => '/admin/home-sections', 'icon' => '🏠', 'label' => 'سکشن‌ها', 'match' => '/admin/home-sections', 'badgeHtml' => ''],
        ['url' => '/admin/products', 'icon' => '📦', 'label' => 'محصولات', 'match' => '/admin/products', 'badgeHtml' => ''],
        ['url' => '/admin/media', 'icon' => '📁', 'label' => 'رسانه', 'match' => '/admin/media', 'badgeHtml' => ''],
        ['url' => '/admin/contact-submissions', 'icon' => '📬', 'label' => 'پیام‌ها', 'match' => '/admin/contact-submissions', 'badgeHtml' => $newMessageCount > 0 ? '<span style="background:#dc2626;color:white;font-size:11px;font-weight:700;padding:2px 8px;border-radius:10px;margin-right:auto;">' . $newMessageCount . '</span>' : ''],
        ['url' => '/admin/languages', 'icon' => '🌐', 'label' => 'زبان‌ها', 'match' => '/admin/languages', 'badgeHtml' => ''],
        ['url' => '/admin/settings', 'icon' => '⚙️', 'label' => 'تنظیمات', 'match' => '/admin/settings', 'badgeHtml' => ''],
    ];

    foreach ($navItems as &$nav) {
        $isExact = ($nav['match'] === '/admin');
        $isActive = $isExact
            ? ($currentPath === '/admin' || $currentPath === '/admin/')
            : str_starts_with($currentPath, $nav['match']);
        $nav['activeClass'] = $isActive ? 'active' : '';
    }
    unset($nav);

    return [
        'arasbFont' => $font,
        'arasbSettings' => $settings,
        'navItems' => $navItems,
    ];
}

function arasb_render_bladeish(string $html, array $data): string
{
    // 1) @foreach($collection as $item) ... @endforeach
    $html = preg_replace_callback(
        '/@foreach\s*\(\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s+as\s+\$([a-zA-Z_][a-zA-Z0-9_]*)\s*\)(.*?)@endforeach/s',
        function ($matches) use ($data) {
            $collectionKey = $matches[1];
            $itemKey = $matches[2];
            $inner = $matches[3];
            $collection = $data[$collectionKey] ?? [];
            $output = '';
            if (is_array($collection)) {
                foreach ($collection as $item) {
                    $scope = $data;
                    $scope[$itemKey] = $item;
                    $output .= arasb_render_bladeish($inner, $scope);
                }
            }
            return $output;
        },
        $html
    );

    // 2) @if($var['key'] !== 'value') ... @else ... @endif  (MUST come before ===)
    $html = preg_replace_callback(
        '/@if\s*\(\s*\$([a-zA-Z_][a-zA-Z0-9_]*)((?:\[[^\]]+\])*)\s*!==\s*[\'"]([^\'"]*)[\'"]\s*\)(.*?)@endif/s',
        function ($matches) use ($data) {
            $var = $matches[1];
            $path = $matches[2];
            $val = $matches[3];
            $inner = $matches[4];
            $value = arasb_resolve_var($data, $var, $path);
            if ((string)($value ?? '') !== $val) {
                $inner = preg_replace('/@else.*$/s', '', $inner);
                return arasb_render_bladeish($inner, $data);
            } else {
                if (preg_match('/@else(.*)$/s', $inner, $elseMatch)) {
                    return arasb_render_bladeish($elseMatch[1], $data);
                }
                return '';
            }
        },
        $html
    );

    // 3) @if($var['key'] === 'value') ... @else ... @endif
    $html = preg_replace_callback(
        '/@if\s*\(\s*\$([a-zA-Z_][a-zA-Z0-9_]*)((?:\[[^\]]+\])*)\s*===\s*[\'"]([^\'"]*)[\'"]\s*\)(.*?)@endif/s',
        function ($matches) use ($data) {
            $var = $matches[1];
            $path = $matches[2];
            $val = $matches[3];
            $inner = $matches[4];
            $value = arasb_resolve_var($data, $var, $path);
            if ((string)($value ?? '') === $val) {
                $inner = preg_replace('/@else.*$/s', '', $inner);
                return arasb_render_bladeish($inner, $data);
            } else {
                if (preg_match('/@else(.*)$/s', $inner, $elseMatch)) {
                    return arasb_render_bladeish($elseMatch[1], $data);
                }
                return '';
            }
        },
        $html
    );

    // 4) @if($var === 'value') ... @else ... @endif (simple, no array access)
    $html = preg_replace_callback(
        '/@if\s*\(\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s*===\s*[\'"]([^\'"]*)[\'"]\s*\)(.*?)@endif/s',
        function ($matches) use ($data) {
            $key = $matches[1];
            $val = $matches[2];
            $inner = $matches[3];
            $actual = $data[$key] ?? '';
            if (is_string($actual) || is_numeric($actual)) {
                if ((string)$actual === $val) {
                    $inner = preg_replace('/@else.*$/s', '', $inner);
                    return arasb_render_bladeish($inner, $data);
                }
            }
            if (preg_match('/@else(.*)$/s', $inner, $elseMatch)) {
                return arasb_render_bladeish($elseMatch[1], $data);
            }
            return '';
        },
        $html
    );

    // 5) @if($var) ... @else ... @endif (truthy check, simple var only)
    $html = preg_replace_callback(
        '/@if\s*\(\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s*\)(.*?)@endif/s',
        function ($matches) use ($data) {
            $key = $matches[1];
            $inner = $matches[2];
            if (!empty($data[$key])) {
                $inner = preg_replace('/@else.*$/s', '', $inner);
                return arasb_render_bladeish($inner, $data);
            } else {
                if (preg_match('/@else(.*)$/s', $inner, $elseMatch)) {
                    return arasb_render_bladeish($elseMatch[1], $data);
                }
                return '';
            }
        },
        $html
    );

    // 6) {{ $var['key1']['key2'] ?? 'fallback' }}
    $html = preg_replace_callback(
        '/\{\{\s*\$([a-zA-Z_][a-zA-Z0-9_]*)((?:\[[^\]]+\])+)\s*\?\?\s*[\'"]([^\'"]*)[\'"]\s*\}\}/',
        function ($matches) use ($data) {
            $var = $matches[1];
            $path = $matches[2];
            $fallback = $matches[3];
            $value = arasb_resolve_var($data, $var, $path);
            $result = $value !== null ? $value : $fallback;
            if (is_array($result)) {
                return '';
            }
            return htmlspecialchars((string)$result, ENT_QUOTES, 'UTF-8');
        },
        $html
    );

    // 7) {{ $var['key1']['key2'] }}
    $html = preg_replace_callback(
        '/\{\{\s*\$([a-zA-Z_][a-zA-Z0-9_]*)((?:\[[^\]]+\])+)\s*\}\}/',
        function ($matches) use ($data) {
            $var = $matches[1];
            $path = $matches[2];
            $value = arasb_resolve_var($data, $var, $path);
            if (is_array($value)) {
                return '';
            }
            return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
        },
        $html
    );

    // 8) {{ $var ?? 'fallback' }}
    $html = preg_replace_callback(
        '/\{\{\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s*\?\?\s*[\'"]([^\'"]*)[\'"]\s*\}\}/',
        function ($matches) use ($data) {
            $key = $matches[1];
            $fallback = $matches[2];
            $value = $data[$key] ?? $fallback;
            if (is_array($value)) {
                return '';
            }
            return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
        },
        $html
    );

    // 9) {{ $var ?? 0 }}
    $html = preg_replace_callback(
        '/\{\{\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s*\?\?\s*(\d+)\s*\}\}/',
        function ($matches) use ($data) {
            $key = $matches[1];
            $fallback = $matches[2];
            $val = $data[$key] ?? $fallback;
            if (is_array($val)) {
                return '';
            }
            return htmlspecialchars((string)$val, ENT_QUOTES, 'UTF-8');
        },
        $html
    );

    // 10) {{ $var }}
    $html = preg_replace_callback(
        '/\{\{\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}/',
        function ($matches) use ($data) {
            $key = $matches[1];
            $value = $data[$key] ?? '';
            if (is_array($value)) {
                return '';
            }
            return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
        },
        $html
    );

    // 11) {!! $var['key'] !!} — RAW HTML output (no escaping)
    $html = preg_replace_callback(
        '/\{!!\s*\$([a-zA-Z_][a-zA-Z0-9_]*)((?:\[[^\]]+\])*)\s*!!\}/',
        function ($matches) use ($data) {
            $var = $matches[1];
            $path = $matches[2];
            $value = arasb_resolve_var($data, $var, $path);
            if (is_array($value)) {
                return '';
            }
            return (string)($value ?? '');
        },
        $html
    );

    // 12) {!! $var !!} — RAW HTML output (no escaping, simple var)
    $html = preg_replace_callback(
        '/\{!!\s*\$([a-zA-Z_][a-zA-Z0-9_]*)\s*!!\}/',
        function ($matches) use ($data) {
            $key = $matches[1];
            $value = $data[$key] ?? '';
            if (is_array($value)) {
                return '';
            }
            return (string)$value;
        },
        $html
    );

    return $html;
}

function arasb_resolve_var(array $data, string $var, string $path)
{
    $value = $data[$var] ?? null;
    if ($path === '') return $value;

    if (preg_match_all('/\[\s*[\'"]([^\'"]+)[\'"]\s*\]/', $path, $keys)) {
        foreach ($keys[1] as $key) {
            if (is_array($value) && array_key_exists($key, $value)) {
                $value = $value[$key];
            } else {
                return null;
            }
        }
    }
    return $value;
}

function arasb_redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

function arasb_auth_check(): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    return !empty($_SESSION['arasb_admin_logged_in']);
}

function arasb_auth_login(string $email): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['arasb_admin_logged_in'] = true;
    $_SESSION['arasb_admin_email'] = $email;
}

function arasb_auth_logout(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    unset($_SESSION['arasb_admin_logged_in'], $_SESSION['arasb_admin_email']);
}
