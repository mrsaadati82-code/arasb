<?php

namespace App\Support;

class Mailer
{
    private string $host;
    private int $port;
    private string $username;
    private string $password;
    private string $fromEmail;
    private string $fromName;
    private string $encryption;
    private bool $enabled;

    public function __construct()
    {
        $settings = [];
        foreach (DataStore::read('settings') as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        $this->host = $settings['smtp_host'] ?? '';
        $this->port = (int) ($settings['smtp_port'] ?? 587);
        $this->username = $settings['smtp_username'] ?? '';
        $this->password = $settings['smtp_password'] ?? '';
        $this->fromEmail = $settings['smtp_from_email'] ?? $settings['email'] ?? 'noreply@arasbtrading.com';
        $this->fromName = $settings['smtp_from_name'] ?? $settings['company_name'] ?? 'ARASB Trading';
        $this->encryption = $settings['smtp_encryption'] ?? 'tls';
        $this->enabled = !empty($this->host) && !empty($this->username);
    }

    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * Send email via SMTP
     */
    public function send(string $to, string $subject, string $htmlBody, string $toName = ''): array
    {
        if (!$this->enabled) {
            return ['success' => false, 'error' => 'SMTP not configured'];
        }

        try {
            // Connect to SMTP server
            $context = stream_context_create([
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ],
            ]);

            $protocol = $this->encryption === 'ssl' ? 'ssl://' : '';
            $socket = stream_socket_client(
                "{$protocol}{$this->host}:{$this->port}",
                $errno,
                $errstr,
                30,
                STREAM_CLIENT_CONNECT,
                $context
            );

            if (!$socket) {
                return ['success' => false, 'error' => "Connection failed: {$errstr} ({$errno})"];
            }

            // Read server greeting
            $this->getResponse($socket);

            // EHLO
            $this->sendCommand($socket, "EHLO " . gethostname());
            
            // STARTTLS if needed
            if ($this->encryption === 'tls') {
                $this->sendCommand($socket, "STARTTLS");
                stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                $this->sendCommand($socket, "EHLO " . gethostname());
            }

            // AUTH LOGIN
            $this->sendCommand($socket, "AUTH LOGIN");
            $this->sendCommand($socket, base64_encode($this->username));
            $this->sendCommand($socket, base64_encode($this->password));

            // MAIL FROM
            $this->sendCommand($socket, "MAIL FROM:<{$this->fromEmail}>");

            // RCPT TO
            $this->sendCommand($socket, "RCPT TO:<{$to}>");

            // DATA
            $this->sendCommand($socket, "DATA");

            // Build email headers
            $headers = "From: {$this->fromName} <{$this->fromEmail}>\r\n";
            $headers .= "To: {$toName} <{$to}>\r\n";
            $headers .= "Subject: {$subject}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "Content-Transfer-Encoding: 8bit\r\n";
            $headers .= "Date: " . date('r') . "\r\n";
            $headers .= "Message-ID: <" . uniqid() . "@" . gethostname() . ">\r\n";
            $headers .= "\r\n";
            $headers .= $htmlBody;
            $headers .= "\r\n.";

            $this->sendCommand($socket, $headers);

            // QUIT
            $this->sendCommand($socket, "QUIT");
            fclose($socket);

            return ['success' => true];

        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Send contact form notification to admin
     */
    public function sendContactNotification(array $submission): array
    {
        $settings = [];
        foreach (DataStore::read('settings') as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        $adminEmail = $settings['email'] ?? '';
        if (empty($adminEmail)) {
            return ['success' => false, 'error' => 'Admin email not configured'];
        }

        $lang = $submission['language_code'] ?? 'en';
        
        // Build bilingual email
        $html = $this->buildContactEmailTemplate($submission, $lang);
        
        $subject = "📬 New Contact Form - " . ($submission['full_name'] ?? 'Unknown');
        
        return $this->send($adminEmail, $subject, $html, 'ARASB Admin');
    }

    /**
     * Build contact form email template
     */
    private function buildContactEmailTemplate(array $data, string $lang): string
    {
        $name = htmlspecialchars($data['full_name'] ?? '');
        $email = htmlspecialchars($data['email'] ?? '');
        $mobile = htmlspecialchars($data['mobile'] ?? '-');
        $company = htmlspecialchars($data['company_name'] ?? '-');
        $country = htmlspecialchars($data['country'] ?? '-');
        $subject = htmlspecialchars($data['subject'] ?? '-');
        $message = nl2br(htmlspecialchars($data['message'] ?? ''));
        $date = date('Y-m-d H:i:s');
        $sourcePage = htmlspecialchars($data['source_page'] ?? '-');
        $ip = htmlspecialchars($data['ip_address'] ?? '-');

        return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family: 'Segoe UI', Tahoma, sans-serif; background: #f1f5f9; padding: 20px; direction: ltr;">
    <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
        <div style="background: #1e293b; padding: 24px 30px; color: white;">
            <h1 style="margin: 0; font-size: 20px;">📬 New Contact Form Submission</h1>
            <p style="margin: 8px 0 0; font-size: 13px; opacity: 0.8;">ARASB Trading - Contact Form</p>
        </div>
        <div style="padding: 30px;">
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Full Name</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$name}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Email</td>
                    <td style="padding: 8px 12px; border-bottom: 1px solid #f1f5f9;"><a href="mailto:{$email}" style="color: #d97706;">{$email}</a></td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Mobile</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$mobile}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Company</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$company}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Country</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$country}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Subject</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$subject}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Source Page</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$sourcePage}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px; border-bottom: 1px solid #f1f5f9;">Date</td>
                    <td style="padding: 8px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #f1f5f9;">{$date}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 12px; font-weight: 600; color: #64748b; font-size: 13px;">IP Address</td>
                    <td style="padding: 8px 12px; color: #94a3b8; font-size: 12px;">{$ip}</td>
                </tr>
            </table>

            <div style="margin-top: 24px; padding: 20px; background: #f8fafc; border-radius: 8px; border-right: 4px solid #d97706;">
                <h3 style="margin: 0 0 12px; font-size: 14px; color: #334155;">💬 Message</h3>
                <div style="font-size: 14px; line-height: 1.6; color: #1e293b;">{$message}</div>
            </div>

            <div style="margin-top: 24px; text-align: center;">
                <a href="mailto:{$email}" style="display: inline-block; padding: 12px 32px; background: #d97706; color: white; text-decoration: none; border-radius: 8px; font-weight: 600;">↩️ Reply to {$name}</a>
            </div>
        </div>
        <div style="padding: 16px 30px; background: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center;">
            <p style="margin: 0; font-size: 12px; color: #94a3b8;">ARASB Trading Admin Panel • Automated Notification</p>
        </div>
    </div>
</body>
</html>
HTML;
    }

    private function getResponse($socket): string
    {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) == ' ') {
                break;
            }
        }
        return $response;
    }

    private function sendCommand($socket, string $command): string
    {
        fwrite($socket, $command . "\r\n");
        return $this->getResponse($socket);
    }
}
