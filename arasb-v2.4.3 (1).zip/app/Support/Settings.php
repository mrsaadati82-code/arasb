<?php

namespace App\Support;

class Settings
{
    public static function all(): array
    {
        $items = DataStore::read('settings');
        $settings = [];

        foreach ($items as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        return $settings;
    }

    public static function get(string $key, string $default = ''): string
    {
        $settings = self::all();
        return (string)($settings[$key] ?? $default);
    }
}
