<?php

namespace App\Support;

use Exception;

class MediaManager
{
    private static string $uploadPath = '';
    private static string $webPath = '/uploads';

    public static function init(): void
    {
        self::$uploadPath = dirname(__DIR__, 2) . '/public/uploads';
        
        if (!is_dir(self::$uploadPath)) {
            mkdir(self::$uploadPath, 0755, true);
        }
    }

    public static function upload(array $file): array
    {
        self::init();

        try {
            // Validate file
            if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
                return ['success' => false, 'error' => 'Invalid file upload'];
            }

            // Check file size (max 10MB)
            $maxSize = 10 * 1024 * 1024;
            if ($file['size'] > $maxSize) {
                return ['success' => false, 'error' => 'حجم فایل بیش از ۱۰ مگابایت است'];
            }

            // Validate MIME type
            $allowedTypes = [
                'image/jpeg',
                'image/jpg',
                'image/png',
                'image/gif',
                'image/webp',
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ];

            if (!in_array($file['type'], $allowedTypes)) {
                return ['success' => false, 'error' => 'فرمت فایل مجاز نیست'];
            }

            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = date('Y-m-d') . '_' . uniqid() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
            $filepath = self::$uploadPath . '/' . $filename;

            // Move file
            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                return ['success' => false, 'error' => 'خطا در ذخیره فایل'];
            }

            // Optimize image if it's an image
            $mimeType = $file['type'] ?? '';
            if (str_starts_with($mimeType, 'image/') && $mimeType !== 'image/gif') {
                try {
                    ImageOptimizer::optimize($filepath);
                    // Update file size after optimization
                    $file['size'] = filesize($filepath);
                } catch (\Throwable $e) {
                    // Continue even if optimization fails
                }
            }

            // Save to JSON
            $mediaData = [
                'filename' => $filename,
                'original_name' => $file['name'],
                'mime_type' => $file['type'],
                'size' => $file['size'],
                'path' => self::$webPath . '/' . $filename,
                'alt_text' => '',
                'uploaded_by' => 0,
            ];

            $media = self::getAll();
            $mediaData['id'] = count($media) + 1;
            $media[] = $mediaData;
            DataStore::write('media', $media);

            return ['success' => true, 'file' => $mediaData];

        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public static function getAll(): array
    {
        return DataStore::read('media');
    }

    public static function delete(int $id): bool
    {
        try {
            // Get file info
            $file = null;
            $media = DataStore::read('media');
            
            foreach ($media as $item) {
                if (($item['id'] ?? 0) == $id) {
                    $file = $item;
                    break;
                }
            }

            if (!$file) {
                return false;
            }

            // Delete physical file
            $filepath = self::$uploadPath . '/' . $file['filename'];
            if (file_exists($filepath)) {
                unlink($filepath);
            }

            // Delete from JSON
            $media = array_filter($media, fn($item) => ($item['id'] ?? 0) != $id);
            DataStore::write('media', array_values($media));

            return true;

        } catch (Exception $e) {
            return false;
        }
    }

    public static function getPath(string $filename): string
    {
        return self::$webPath . '/' . $filename;
    }
}
