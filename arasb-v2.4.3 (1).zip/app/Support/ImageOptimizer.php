<?php

namespace App\Support;

class ImageOptimizer
{
    private static int $maxWidth = 1920;
    private static int $maxHeight = 1920;
    private static int $thumbnailWidth = 400;
    private static int $thumbnailHeight = 400;
    private static int $quality = 85;

    /**
     * Resize image if larger than max dimensions
     */
    public static function optimize(string $filepath): array
    {
        if (!extension_loaded('gd')) {
            return ['optimized' => false, 'reason' => 'GD extension not available'];
        }

        $info = @getimagesize($filepath);
        if (!$info) {
            return ['optimized' => false, 'reason' => 'Not a valid image'];
        }

        [$width, $height, $type] = $info;
        $mime = $info['mime'] ?? '';

        // Skip if not an image or too small
        if ($width <= self::$maxWidth && $height <= self::$maxHeight) {
            // Still compress for quality
            if (in_array($mime, ['image/jpeg', 'image/png'])) {
                self::recompress($filepath, $type, $width, $height);
                return ['optimized' => true, 'reason' => 'Compressed'];
            }
            return ['optimized' => false, 'reason' => 'Already optimal size'];
        }

        // Calculate new dimensions
        $ratio = min(self::$maxWidth / $width, self::$maxHeight / $height);
        $newWidth = (int) round($width * $ratio);
        $newHeight = (int) round($height * $ratio);

        // Create new image
        $source = self::createFromFile($filepath, $type);
        if (!$source) {
            return ['optimized' => false, 'reason' => 'Failed to load image'];
        }

        $dest = imagecreatetruecolor($newWidth, $newHeight);

        // Preserve transparency for PNG
        if ($type === IMAGETYPE_PNG) {
            imagealphablending($dest, false);
            imagesavealpha($dest, true);
            $transparent = imagecolorallocatealpha($dest, 0, 0, 0, 127);
            imagefill($dest, 0, 0, $transparent);
        }

        imagecopyresampled($dest, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        // Save
        self::saveToFile($dest, $filepath, $type);

        imagedestroy($source);
        imagedestroy($dest);

        return ['optimized' => true, 'newWidth' => $newWidth, 'newHeight' => $newHeight];
    }

    /**
     * Generate thumbnail
     */
    public static function thumbnail(string $filepath, string $thumbPath): bool
    {
        if (!extension_loaded('gd')) {
            return false;
        }

        $info = @getimagesize($filepath);
        if (!$info) {
            return false;
        }

        [$width, $height, $type] = $info;

        // Calculate thumbnail dimensions (maintain aspect ratio)
        $ratio = min(self::$thumbnailWidth / $width, self::$thumbnailHeight / $height);
        $newWidth = (int) round($width * $ratio);
        $newHeight = (int) round($height * $ratio);

        $source = self::createFromFile($filepath, $type);
        if (!$source) {
            return false;
        }

        $dest = imagecreatetruecolor($newWidth, $newHeight);

        if ($type === IMAGETYPE_PNG) {
            imagealphablending($dest, false);
            imagesavealpha($dest, true);
            $transparent = imagecolorallocatealpha($dest, 0, 0, 0, 127);
            imagefill($dest, 0, 0, $transparent);
        }

        imagecopyresampled($dest, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
        self::saveToFile($dest, $thumbPath, $type);

        imagedestroy($source);
        imagedestroy($dest);

        return true;
    }

    private static function recompress(string $filepath, int $type, int $width, int $height): void
    {
        $source = self::createFromFile($filepath, $type);
        if (!$source) return;

        $dest = imagecreatetruecolor($width, $height);

        if ($type === IMAGETYPE_PNG) {
            imagealphablending($dest, false);
            imagesavealpha($dest, true);
        }

        imagecopy($dest, $source, 0, 0, 0, 0, $width, $height);
        self::saveToFile($dest, $filepath, $type);

        imagedestroy($source);
        imagedestroy($dest);
    }

    private static function createFromFile(string $filepath, int $type)
    {
        switch ($type) {
            case IMAGETYPE_JPEG: return imagecreatefromjpeg($filepath);
            case IMAGETYPE_PNG: return imagecreatefrompng($filepath);
            case IMAGETYPE_GIF: return imagecreatefromgif($filepath);
            case IMAGETYPE_WEBP:
                if (function_exists('imagecreatefromwebp')) {
                    return imagecreatefromwebp($filepath);
                }
                return null;
            default: return null;
        }
    }

    private static function saveToFile($image, string $filepath, int $type): void
    {
        switch ($type) {
            case IMAGETYPE_JPEG:
                imagejpeg($image, $filepath, self::$quality);
                break;
            case IMAGETYPE_PNG:
                imagepng($image, $filepath, 6); // 0-9, 6 is good balance
                break;
            case IMAGETYPE_GIF:
                imagegif($image, $filepath);
                break;
            case IMAGETYPE_WEBP:
                if (function_exists('imagewebp')) {
                    imagewebp($image, $filepath, self::$quality);
                }
                break;
        }
    }
}
