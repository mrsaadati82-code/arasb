<?php

namespace App\Models;

class Language
{
    public string $code;
    public string $name;
    public string $nativeName;
    public string $direction;
    public bool $isDefault = false;
    public bool $isActive = true;
}
