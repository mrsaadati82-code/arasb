<?php

namespace App\Models;

class Page
{
    public string $type;
    public string $slugBase;
    public string $status;
    public string $templateKey;
}
