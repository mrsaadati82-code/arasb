<?php

namespace App\Models;

class Product
{
    public int $productCategoryId;
    public ?string $sku = null;
    public string $slugBase;
    public string $status;
    public bool $isFeatured = false;
}
