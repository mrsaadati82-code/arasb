<?php

namespace App\Models;

class Setting
{
    public string $groupKey;
    public string $key;
    public string $valueType;
    public ?string $valueText = null;
    public ?string $valueJson = null;
    public bool $isPublic = false;
}
