<?php

namespace App\Http\Controllers\Api;

use App\Support\DataStore;
use App\Support\Mailer;

class PublicApiController
{
    private function json(array $payload, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    private function getLocale(): string
    {
        return trim($_GET['locale'] ?? 'en');
    }

    public function settings(): void
    {
        $items = DataStore::read('settings');
        $settings = [];

        // Public settings only (exclude SMTP and sensitive data)
        $publicKeys = [
            'company_name', 'email', 'phone', 'site_title',
            'primary_domain', 'default_language', 'font_family',
        ];

        foreach ($items as $item) {
            $key = $item['setting_key'] ?? '';
            if (in_array($key, $publicKeys)) {
                $settings[$key] = $item['value'] ?? '';
            }
        }

        $this->json([
            'success' => true,
            'data' => $settings,
        ]);
    }

    public function languages(): void
    {
        $this->json([
            'success' => true,
            'data' => DataStore::read('languages'),
        ]);
    }

    public function homeSections(): void
    {
        $locale = $this->getLocale();
        $items = DataStore::read('home_sections');
        $result = [];

        foreach ($items as $item) {
            $result[] = [
                'id' => $item['id'] ?? 0,
                'page_key' => $item['page_key'] ?? 'home',
                'section_key' => $item['section_key'] ?? '',
                'section_type' => $item['section_type'] ?? 'content',
                'is_active' => (int)($item['is_active'] ?? 0),
                'sort_order' => (int)($item['sort_order'] ?? 0),
                'translation' => $item['translations'][$locale] ?? ($item['translations']['en'] ?? []),
                'translations' => $item['translations'] ?? [],
            ];
        }

        $this->json([
            'success' => true,
            'locale' => $locale,
            'data' => $result,
        ]);
    }

    public function products(): void
    {
        $locale = $this->getLocale();
        $items = DataStore::read('products');
        $result = [];

        foreach ($items as $item) {
            $status = $item['status'] ?? '';
            if ($status !== 'published' && $status !== 'منتشرشده') {
                continue;
            }

            $translation = $item['translations'][$locale] ?? ($item['translations']['en'] ?? []);
            $category = $this->resolveCategory($item, $locale);

            $result[] = [
                'id' => $item['id'] ?? 0,
                'slug' => $item['slug'] ?? '',
                'image' => $item['image'] ?? '/default-product.jpg',
                'category' => $category,
                'sort_order' => (int)($item['sort_order'] ?? 0),
                'title' => $translation['title'] ?? '',
                'description' => $translation['description'] ?? '',
            ];
        }

        usort($result, fn($a, $b) => $a['sort_order'] <=> $b['sort_order']);

        $this->json([
            'success' => true,
            'locale' => $locale,
            'total' => count($result),
            'data' => $result,
        ]);
    }

    /**
     * Product Detail by slug
     */
    public function productDetail(): void
    {
        $locale = $this->getLocale();
        $slug = trim($_GET['slug'] ?? '');

        if ($slug === '') {
            $this->json(['success' => false, 'message' => 'Slug is required.'], 400);
        }

        $items = DataStore::read('products');
        $product = null;

        foreach ($items as $item) {
            if (($item['slug'] ?? '') === $slug) {
                $product = $item;
                break;
            }
        }

        if (!$product) {
            $this->json(['success' => false, 'message' => 'Product not found.'], 404);
        }

        $status = $product['status'] ?? '';
        if ($status !== 'published' && $status !== 'منتشرشده') {
            $this->json(['success' => false, 'message' => 'Product not found.'], 404);
        }

        $translation = $product['translations'][$locale] ?? ($product['translations']['en'] ?? []);
        $category = $this->resolveCategory($product, $locale);

        $this->json([
            'success' => true,
            'locale' => $locale,
            'data' => [
                'id' => $product['id'] ?? 0,
                'slug' => $product['slug'] ?? '',
                'image' => $product['image'] ?? '',
                'category' => $category,
                'sort_order' => (int)($product['sort_order'] ?? 0),
                'title' => $translation['title'] ?? '',
                'description' => $translation['description'] ?? '',
                'subtitle' => $translation['subtitle'] ?? '',
                'features' => $translation['features'] ?? '',
                'gallery' => $product['gallery'] ?? [],
                'meta_title' => $translation['meta_title'] ?? ($translation['title'] ?? ''),
                'meta_description' => $translation['meta_description'] ?? ($translation['description'] ?? ''),
                'translations' => $product['translations'] ?? [],
            ],
        ]);
    }

    /**
     * Page Detail by slug
     */
    public function pageDetail(): void
    {
        $locale = $this->getLocale();
        $slug = trim($_GET['slug'] ?? '');

        if ($slug === '') {
            $this->json(['success' => false, 'message' => 'Slug is required.'], 400);
        }

        $items = DataStore::read('pages');
        $page = null;

        foreach ($items as $item) {
            if (($item['slug'] ?? '') === $slug) {
                $page = $item;
                break;
            }
        }

        if (!$page) {
            $this->json(['success' => false, 'message' => 'Page not found.'], 404);
        }

        $translation = $page['translations'][$locale] ?? ($page['translations']['en'] ?? []);

        $this->json([
            'success' => true,
            'locale' => $locale,
            'data' => [
                'id' => $page['id'] ?? 0,
                'slug' => $page['slug'] ?? '',
                'title' => $translation['title'] ?? '',
                'content' => $translation['content'] ?? '',
                'excerpt' => $translation['excerpt'] ?? '',
                'meta_title' => $translation['meta_title'] ?? ($translation['title'] ?? ''),
                'meta_description' => $translation['meta_description'] ?? '',
                'translations' => $page['translations'] ?? [],
            ],
        ]);
    }

    /**
     * Search products by keyword
     */
    public function search(): void
    {
        $locale = $this->getLocale();
        $query = trim($_GET['q'] ?? '');

        if ($query === '') {
            $this->json([
                'success' => true,
                'locale' => $locale,
                'query' => '',
                'total' => 0,
                'data' => [],
            ]);
        }

        $items = DataStore::read('products');
        $results = [];
        $queryLower = mb_strtolower($query);

        foreach ($items as $item) {
            $status = $item['status'] ?? '';
            if ($status !== 'published' && $status !== 'منتشرشده') {
                continue;
            }

            $translation = $item['translations'][$locale] ?? ($item['translations']['en'] ?? []);
            $title = mb_strtolower($translation['title'] ?? '');
            $desc = mb_strtolower($translation['description'] ?? '');
            $category = mb_strtolower($this->resolveCategory($item, $locale));

            // Search in title, description, category
            if (
                mb_strpos($title, $queryLower) !== false ||
                mb_strpos($desc, $queryLower) !== false ||
                mb_strpos($category, $queryLower) !== false
            ) {
                $results[] = [
                    'id' => $item['id'] ?? 0,
                    'slug' => $item['slug'] ?? '',
                    'image' => $item['image'] ?? '/default-product.jpg',
                    'category' => $this->resolveCategory($item, $locale),
                    'title' => $translation['title'] ?? '',
                    'description' => $translation['description'] ?? '',
                ];
            }
        }

        $this->json([
            'success' => true,
            'locale' => $locale,
            'query' => $query,
            'total' => count($results),
            'data' => $results,
        ]);
    }

    public function contactSubmit(): void
    {
        // Handle JSON body or form data
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($contentType, 'application/json')) {
            $body = json_decode(file_get_contents('php://input'), true) ?: [];
        } else {
            $body = $_POST;
        }

        // 🍯 Honeypot anti-spam check
        // If honeypot field is filled, it's a bot - silently reject
        $honeypot = trim($body['website_url'] ?? '');
        if ($honeypot !== '') {
            // Pretend success but don't save
            $this->json([
                'success' => true,
                'message' => 'Your message has been received successfully.',
            ]);
        }

        $fullName = trim($body['full_name'] ?? '');
        $email = trim($body['email'] ?? '');
        $mobile = trim($body['mobile'] ?? '');
        $companyName = trim($body['company_name'] ?? '');
        $country = trim($body['country'] ?? '');
        $subject = trim($body['subject'] ?? '');
        $message = trim($body['message'] ?? '');
        $languageCode = trim($body['language_code'] ?? 'en');
        $sourcePage = trim($body['source_page'] ?? 'contact');

        if ($fullName === '' || $email === '' || $message === '') {
            $this->json([
                'success' => false,
                'message' => 'Required fields are missing.',
            ], 422);
        }

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->json([
                'success' => false,
                'message' => 'Invalid email address.',
            ], 422);
        }

        // Simple rate limiting by IP (max 3 per hour)
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $items = DataStore::read('contact_submissions');
        
        $recentCount = 0;
        $oneHourAgo = time() - 3600;
        foreach ($items as $s) {
            if (($s['ip_address'] ?? '') === $ipAddress) {
                $createdAt = strtotime($s['created_at'] ?? '');
                if ($createdAt > $oneHourAgo) {
                    $recentCount++;
                }
            }
        }
        
        if ($recentCount >= 3) {
            $this->json([
                'success' => false,
                'message' => 'Too many submissions. Please try again later.',
            ], 429);
        }

        $submission = [
            'id' => 0,
            'full_name' => $fullName,
            'email' => $email,
            'mobile' => $mobile,
            'company_name' => $companyName,
            'country' => $country,
            'subject' => $subject,
            'message' => $message,
            'language_code' => $languageCode,
            'source_page' => $sourcePage,
            'status' => 'new',
            'ip_address' => $ipAddress,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => date('c'),
        ];

        // Save to JSON
        $submission['id'] = count($items) + 1;
        $items[] = $submission;
        DataStore::write('contact_submissions', $items);

        // Send email notification
        $emailSent = false;
        try {
            $mailer = new Mailer();
            if ($mailer->isEnabled()) {
                $emailResult = $mailer->sendContactNotification($submission);
                $emailSent = $emailResult['success'] ?? false;
            }
        } catch (\Throwable $e) {
            // Silently fail - form submission still succeeds
        }

        $this->json([
            'success' => true,
            'message' => 'Your message has been received successfully.',
            'email_notification' => $emailSent,
        ]);
    }

    private function resolveCategory(array $item, string $locale): string
    {
        if (!isset($item['category'])) {
            return '';
        }
        if (is_array($item['category'])) {
            return $item['category'][$locale] ?? ($item['category']['en'] ?? '');
        }
        return $item['category'];
    }
}
