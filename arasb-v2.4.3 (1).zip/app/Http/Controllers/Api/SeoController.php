<?php

namespace App\Http\Controllers\Api;

use App\Support\DataStore;

class SeoController
{
    /**
     * Generate sitemap.xml
     */
    public function sitemap(): void
    {
        $settings = [];
        foreach (DataStore::read('settings') as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        $domain = rtrim($settings['primary_domain'] ?? 'arasbtrading.com', '/');
        $baseUrl = 'https://' . $domain;
        $languages = ['fa', 'en', 'ar'];

        header('Content-Type: application/xml; charset=utf-8');

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
        $xml .= '        xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";

        // Homepage for each language
        foreach ($languages as $lang) {
            $xml .= "  <url>\n";
            $xml .= "    <loc>{$baseUrl}/{$lang}</loc>\n";
            $xml .= "    <changefreq>daily</changefreq>\n";
            $xml .= "    <priority>1.0</priority>\n";
            foreach ($languages as $altLang) {
                $xml .= "    <xhtml:link rel=\"alternate\" hreflang=\"{$altLang}\" href=\"{$baseUrl}/{$altLang}\" />\n";
            }
            $xml .= "  </url>\n";
        }

        // Products
        $products = DataStore::read('products');
        foreach ($products as $product) {
            $status = $product['status'] ?? '';
            if ($status !== 'published' && $status !== 'منتشرشده') {
                continue;
            }
            $slug = $product['slug'] ?? '';
            if ($slug === '') continue;

            foreach ($languages as $lang) {
                $xml .= "  <url>\n";
                $xml .= "    <loc>{$baseUrl}/{$lang}/products/{$slug}</loc>\n";
                $xml .= "    <changefreq>weekly</changefreq>\n";
                $xml .= "    <priority>0.8</priority>\n";
                foreach ($languages as $altLang) {
                    $xml .= "    <xhtml:link rel=\"alternate\" hreflang=\"{$altLang}\" href=\"{$baseUrl}/{$altLang}/products/{$slug}\" />\n";
                }
                $xml .= "  </url>\n";
            }
        }

        // Pages
        $pages = DataStore::read('pages');
        foreach ($pages as $page) {
            $slug = $page['slug'] ?? '';
            if ($slug === '' || $slug === 'home') continue;

            foreach ($languages as $lang) {
                $xml .= "  <url>\n";
                $xml .= "    <loc>{$baseUrl}/{$lang}/{$slug}</loc>\n";
                $xml .= "    <changefreq>monthly</changefreq>\n";
                $xml .= "    <priority>0.6</priority>\n";
                foreach ($languages as $altLang) {
                    $xml .= "    <xhtml:link rel=\"alternate\" hreflang=\"{$altLang}\" href=\"{$baseUrl}/{$altLang}/{$slug}\" />\n";
                }
                $xml .= "  </url>\n";
            }
        }

        $xml .= '</urlset>';
        echo $xml;
        exit;
    }

    /**
     * Generate robots.txt
     */
    public function robots(): void
    {
        $settings = [];
        foreach (DataStore::read('settings') as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        $domain = rtrim($settings['primary_domain'] ?? 'arasbtrading.com', '/');
        $baseUrl = 'https://' . $domain;

        header('Content-Type: text/plain; charset=utf-8');

        $txt = "User-agent: *\n";
        $txt .= "Allow: /\n";
        $txt .= "Disallow: /admin/\n";
        $txt .= "Disallow: /api/\n";
        $txt .= "Disallow: /install.php\n";
        $txt .= "\n";
        $txt .= "Sitemap: {$baseUrl}/sitemap.xml\n";

        echo $txt;
        exit;
    }
}
