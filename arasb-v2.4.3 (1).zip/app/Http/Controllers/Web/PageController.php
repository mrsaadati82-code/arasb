<?php

namespace App\Http\Controllers\Web;

class PageController
{
    private function common(string $locale, string $title): array
    {
        return [
            'locale' => $locale,
            'dir' => in_array($locale, ['fa', 'ar'], true) ? 'rtl' : 'ltr',
            'title' => $title,
        ];
    }

    public function home(string $locale = 'en'): array
    {
        $copy = [
            'en' => [
                'title' => 'Premium Iranian Exports',
                'eyebrow' => 'Leading Export Partner',
                'lead' => 'Specialized in premium Iranian products for international markets, with a presentation aligned to the ARASB visual identity.',
            ],
            'fa' => [
                'title' => 'صادرات ممتاز ایرانی',
                'eyebrow' => 'شریک پیشرو صادرات',
                'lead' => 'متخصص در ارائه محصولات ممتاز ایرانی برای بازارهای بین‌المللی، با هویتی بصری هم‌راستا با برند آراسب.',
            ],
            'ar' => [
                'title' => 'صادرات إيرانية متميزة',
                'eyebrow' => 'شريك تصدير رائد',
                'lead' => 'متخصصون في تقديم المنتجات الإيرانية المتميزة للأسواق الدولية مع الحفاظ على الهوية البصرية لآراسب.',
            ],
        ];

        return [
            'view' => 'web.home',
            'data' => array_merge($this->common($locale, 'ARASB Home'), $copy[$locale] ?? $copy['en']),
        ];
    }

    public function about(string $locale = 'en'): array
    {
        return ['view' => 'web.about', 'data' => $this->common($locale, 'About ARASB')];
    }

    public function products(string $locale = 'en'): array
    {
        return ['view' => 'web.products', 'data' => $this->common($locale, 'Products')];
    }

    public function contact(string $locale = 'en'): array
    {
        return ['view' => 'web.contact', 'data' => $this->common($locale, 'Contact')];
    }
}
