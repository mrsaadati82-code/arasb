<?php

namespace App\Http\Controllers\Auth;

class AdminLoginController
{
    public function showLogin(): array
    {
        return ['view' => 'admin.login', 'data' => ['title' => 'ورود به پنل مدیریت']];
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? 'admin@arasb.local');
        $password = trim($_POST['password'] ?? '');

        if ($email !== '' && $password !== '') {
            arasb_auth_login($email);
            arasb_redirect('/admin');
        }

        arasb_redirect('/admin/login');
    }

    public function logout(): void
    {
        arasb_auth_logout();
        arasb_redirect('/admin/login');
    }
}
