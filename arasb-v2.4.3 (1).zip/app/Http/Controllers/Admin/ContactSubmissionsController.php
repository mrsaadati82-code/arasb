<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class ContactSubmissionsController
{
    public function index(): array
    {
        $items = array_reverse(DataStore::read('contact_submissions'));

        // Prepare items for blade-ish renderer
        $prepared = [];
        foreach ($items as $item) {
            $prepared[] = [
                'id' => (int) ($item['id'] ?? 0),
                'full_name' => $item['full_name'] ?? '-',
                'email' => $item['email'] ?? '-',
                'mobile' => $item['mobile'] ?? '-',
                'company_name' => $item['company_name'] ?? '-',
                'country' => $item['country'] ?? '-',
                'subject' => $item['subject'] ?? '-',
                'message' => $item['message'] ?? '-',
                'language_code' => $item['language_code'] ?? 'en',
                'source_page' => $item['source_page'] ?? '-',
                'status' => $item['status'] ?? 'new',
                'ip_address' => $item['ip_address'] ?? '-',
                'created_at' => $item['created_at'] ?? '-',
            ];
        }

        return [
            'view' => 'admin.contact-submissions.index',
            'data' => [
                'title' => 'پیام‌های تماس',
                'items' => $prepared,
                'hasItems' => !empty($prepared),
                'totalCount' => count($prepared),
            ],
        ];
    }

    public function markRead(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        
        if ($id > 0) {
            $items = DataStore::read('contact_submissions');
            foreach ($items as &$item) {
                // Use loose comparison to handle string/int mismatch
                if (($item['id'] ?? 0) == $id) {
                    $item['status'] = 'read';
                    break;
                }
            }
            unset($item);
            DataStore::write('contact_submissions', $items);
        }

        header('Location: /admin/contact-submissions');
        exit;
    }

    public function delete(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        
        if ($id > 0) {
            $items = DataStore::read('contact_submissions');
            $items = array_values(array_filter($items, fn($item) => ($item['id'] ?? 0) != $id));
            DataStore::write('contact_submissions', $items);
        }

        header('Location: /admin/contact-submissions');
        exit;
    }

    public function export(): void
    {
        $items = DataStore::read('contact_submissions');

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="contact-submissions-' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        // BOM for Excel UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        fputcsv($output, ['ID', 'Name', 'Email', 'Mobile', 'Company', 'Country', 'Subject', 'Message', 'Language', 'Source', 'Status', 'IP', 'Date']);

        foreach ($items as $item) {
            fputcsv($output, [
                $item['id'] ?? '',
                $item['full_name'] ?? '',
                $item['email'] ?? '',
                $item['mobile'] ?? '',
                $item['company_name'] ?? '',
                $item['country'] ?? '',
                $item['subject'] ?? '',
                $item['message'] ?? '',
                $item['language_code'] ?? '',
                $item['source_page'] ?? '',
                $item['status'] ?? '',
                $item['ip_address'] ?? '',
                $item['created_at'] ?? '',
            ]);
        }

        fclose($output);
        exit;
    }
}
