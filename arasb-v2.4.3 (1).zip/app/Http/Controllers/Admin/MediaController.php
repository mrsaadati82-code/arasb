<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;
use App\Support\MediaManager;

class MediaController
{
    public function index(): array
    {
        $media = MediaManager::getAll();
        
        // Prepare media items for blade-ish renderer
        $preparedMedia = [];
        foreach ($media as $item) {
            $size = $item['size'] ?? 0;
            $sizeFormatted = $size > 1048576 
                ? round($size / 1048576, 1) . ' MB' 
                : round($size / 1024, 1) . ' KB';
            
            $originalName = $item['original_name'] ?? '';
            $shortName = mb_strlen($originalName) > 25 
                ? mb_substr($originalName, 0, 22) . '...' 
                : $originalName;
            
            $mimeType = $item['mime_type'] ?? '';
            $isImage = str_starts_with($mimeType, 'image/') ? 1 : 0;
            
            $preparedMedia[] = [
                'id' => $item['id'] ?? 0,
                'path' => $item['path'] ?? '',
                'original_name' => $originalName,
                'short_name' => $shortName,
                'size_formatted' => $sizeFormatted,
                'is_image' => $isImage,
                'mime_type' => $mimeType,
                'filename' => $item['filename'] ?? '',
            ];
        }
        
        $uploadedCount = 0;
        if (!empty($_GET['uploaded'])) {
            $uploadedCount = (int) $_GET['uploaded'];
        }
        
        $errorMsg = '';
        if (!empty($_GET['error'])) {
            $errorMsg = $_GET['error'];
        }
        
        return [
            'view' => 'admin.media.index',
            'data' => [
                'title' => '📁 مدیریت رسانه',
                'media' => $preparedMedia,
                'mediaCount' => count($preparedMedia),
                'uploadedCount' => $uploadedCount,
                'errorMsg' => $errorMsg,
            ],
        ];
    }

    public function upload(): void
    {
        $uploadedCount = 0;
        $errors = [];

        if (!empty($_FILES['files'])) {
            $files = $_FILES['files'];
            
            // Normalize to array
            if (!is_array($files['name'])) {
                $files = [
                    'name' => [$files['name']],
                    'type' => [$files['type']],
                    'tmp_name' => [$files['tmp_name']],
                    'error' => [$files['error']],
                    'size' => [$files['size']],
                ];
            }

            for ($i = 0; $i < count($files['name']); $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $result = MediaManager::upload([
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'size' => $files['size'][$i],
                    ]);

                    if ($result['success']) {
                        $uploadedCount++;
                    } else {
                        $errors[] = $result['error'];
                    }
                }
            }
        }

        $redirect = '/admin/media';
        if ($uploadedCount > 0) {
            $redirect .= '?uploaded=' . $uploadedCount;
        }
        if (!empty($errors)) {
            $redirect .= ($uploadedCount > 0 ? '&' : '?') . 'error=' . urlencode(implode(', ', $errors));
        }
        
        header('Location: ' . $redirect);
        exit;
    }

    public function delete(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        
        if ($id > 0) {
            MediaManager::delete($id);
        }

        header('Location: /admin/media');
        exit;
    }
}
