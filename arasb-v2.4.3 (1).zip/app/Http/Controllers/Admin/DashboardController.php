<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class DashboardController
{
    public function index(): array
    {
        // Products
        $products = DataStore::read('products');
        $publishedCount = 0;
        foreach ($products as $p) {
            $status = $p['status'] ?? '';
            if ($status === 'published' || $status === 'منتشرشده') {
                $publishedCount++;
            }
        }

        // Contact submissions
        $submissions = DataStore::read('contact_submissions');
        $totalMessages = count($submissions);
        $newMessages = 0;
        $recentMessages = [];
        foreach ($submissions as $s) {
            if (($s['status'] ?? '') === 'new') {
                $newMessages++;
            }
        }
        // Last 5 messages
        $lastMessages = array_slice(array_reverse($submissions), 0, 5);
        foreach ($lastMessages as $msg) {
            $recentMessages[] = [
                'id' => $msg['id'] ?? 0,
                'name' => $msg['full_name'] ?? '',
                'email' => $msg['email'] ?? '',
                'subject' => $msg['subject'] ?? '-',
                'date' => $msg['created_at'] ?? '',
                'status' => $msg['status'] ?? 'new',
                'is_new' => ($msg['status'] ?? '') === 'new' ? 1 : 0,
            ];
        }
        $recentCount = count($recentMessages);

        // Languages
        $languages = DataStore::read('languages');
        $activeLanguages = 0;
        foreach ($languages as $l) {
            if (!empty($l['is_active'])) {
                $activeLanguages++;
            }
        }

        // Pages
        $pages = DataStore::read('pages');
        $pagesCount = count($pages);

        // Home sections
        $sections = DataStore::read('home_sections');
        $sectionsCount = count($sections);

        // Media
        $media = DataStore::read('media');
        $mediaCount = count($media);

        return [
            'view' => 'admin.dashboard',
            'data' => [
                'title' => 'داشبورد',
                'productCount' => $publishedCount,
                'newMessages' => $newMessages,
                'totalMessages' => $totalMessages,
                'activeLanguages' => $activeLanguages,
                'pagesCount' => $pagesCount,
                'sectionsCount' => $sectionsCount,
                'mediaCount' => $mediaCount,
                'recentMessages' => $recentMessages,
                'recentCount' => $recentCount,
            ],
        ];
    }
}
