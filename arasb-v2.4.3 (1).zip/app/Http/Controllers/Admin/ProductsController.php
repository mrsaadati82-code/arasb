<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class ProductsController
{
    public function index(): array
    {
        return [
            'view' => 'admin.products.index',
            'data' => [
                'title' => 'مدیریت محصولات',
                'items' => DataStore::read('products'),
            ],
        ];
    }

    public function edit(): array
    {
        $id = (int)($_GET['id'] ?? 0);
        $isNew = $id === 0;

        if ($isNew) {
            $item = [
                'id' => 0,
                'slug' => '',
                'image' => '/default-product.jpg',
                'status' => 'draft',
                'sort_order' => 0,
                'category' => ['en' => '', 'fa' => '', 'ar' => ''],
                'translations' => [
                    'en' => ['title' => '', 'description' => ''],
                    'fa' => ['title' => '', 'description' => ''],
                    'ar' => ['title' => '', 'description' => ''],
                ],
            ];
        } else {
            $item = DataStore::findById('products', $id);
            if (!$item) {
                $item = [
                    'id' => $id,
                    'slug' => '',
                    'image' => '/default-product.jpg',
                    'status' => 'draft',
                    'sort_order' => 0,
                    'category' => ['en' => '', 'fa' => '', 'ar' => ''],
                    'translations' => [
                        'en' => ['title' => '', 'description' => ''],
                        'fa' => ['title' => '', 'description' => ''],
                        'ar' => ['title' => '', 'description' => ''],
                    ],
                ];
            }
        }

        return [
            'view' => 'admin.products.edit',
            'data' => [
                'title' => $isNew ? 'محصول جدید' : 'ویرایش محصول',
                'item' => $item,
                'saved' => (int)($_GET['saved'] ?? 0),
            ],
        ];
    }

    public function save(): void
    {
        $items = DataStore::read('products');
        $id = (int)($_POST['id'] ?? 0);

        $payload = [
            'id' => $id > 0 ? $id : (count($items) + 1),
            'slug' => trim($_POST['slug'] ?? ''),
            'image' => trim($_POST['image'] ?? '/default-product.jpg'),
            'status' => trim($_POST['status'] ?? 'draft'),
            'sort_order' => (int)($_POST['sort_order'] ?? 0),
            'category' => [
                'en' => trim($_POST['category_en'] ?? ''),
                'fa' => trim($_POST['category_fa'] ?? ''),
                'ar' => trim($_POST['category_ar'] ?? ''),
            ],
            'translations' => [
                'en' => [
                    'title' => trim($_POST['title_en'] ?? ''),
                    'description' => trim($_POST['description_en'] ?? ''),
                ],
                'fa' => [
                    'title' => trim($_POST['title_fa'] ?? ''),
                    'description' => trim($_POST['description_fa'] ?? ''),
                ],
                'ar' => [
                    'title' => trim($_POST['title_ar'] ?? ''),
                    'description' => trim($_POST['description_ar'] ?? ''),
                ],
            ],
        ];

        $updated = false;
        foreach ($items as $index => $item) {
            if ((int)($item['id'] ?? 0) === $payload['id']) {
                $items[$index] = $payload;
                $updated = true;
                break;
            }
        }

        if (!$updated) {
            $items[] = $payload;
        }

        DataStore::write('products', $items);
        arasb_redirect('/admin/products/edit?id=' . $payload['id'] . '&saved=1');
    }
}
