<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class PagesController
{
    public function index(): array
    {
        return [
            'view' => 'admin.pages.index',
            'data' => [
                'title' => 'مدیریت صفحات',
                'items' => DataStore::read('pages'),
            ],
        ];
    }

    public function edit(): array
    {
        $id = (int)($_GET['id'] ?? 1);
        $item = DataStore::findById('pages', $id) ?? ['id' => 0, 'title' => '', 'type' => 'Standard', 'status' => 'پیش‌نویس', 'translations' => 'FA'];

        return [
            'view' => 'admin.pages.edit',
            'data' => [
                'title' => 'ویرایش صفحه',
                'item' => $item,
                'saved' => (int)($_GET['saved'] ?? 0),
            ],
        ];
    }

    public function save(): void
    {
        $items = DataStore::read('pages');
        $id = (int)($_POST['id'] ?? 0);
        $payload = [
            'id' => $id > 0 ? $id : (count($items) + 1),
            'title' => trim($_POST['title'] ?? ''),
            'type' => trim($_POST['type'] ?? 'Standard'),
            'status' => trim($_POST['status'] ?? 'پیش‌نویس'),
            'translations' => trim($_POST['translations'] ?? 'FA'),
        ];

        $updated = false;
        foreach ($items as $index => $item) {
            if ((int)($item['id'] ?? 0) === $payload['id']) {
                $items[$index] = $payload;
                $updated = true;
                break;
            }
        }

        if (!$updated) {
            $items[] = $payload;
        }

        DataStore::write('pages', $items);
        arasb_redirect('/admin/pages/edit?id=' . $payload['id'] . '&saved=1');
    }
}
