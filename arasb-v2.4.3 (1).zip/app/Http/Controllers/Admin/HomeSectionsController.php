<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class HomeSectionsController
{
    public function index(): array
    {
        return [
            'view' => 'admin.home-sections.index',
            'data' => [
                'title' => '🏠 سکشن‌های صفحه اصلی',
                'items' => DataStore::read('home_sections'),
            ],
        ];
    }

    public function edit(): array
    {
        $id = (int)($_GET['id'] ?? 0);
        $isNew = $id === 0;

        if ($isNew) {
            $item = [
                'id' => 0,
                'page_key' => 'home',
                'section_key' => '',
                'section_type' => 'content',
                'is_active' => 1,
                'sort_order' => 1,
                'translations' => [
                    'fa' => ['badge' => '', 'title' => '', 'subtitle' => '', 'description' => ''],
                    'en' => ['badge' => '', 'title' => '', 'subtitle' => '', 'description' => ''],
                    'ar' => ['badge' => '', 'title' => '', 'subtitle' => '', 'description' => ''],
                ],
            ];
        } else {
            $item = DataStore::findById('home_sections', $id);
            if (!$item) {
                $item = [
                    'id' => $id,
                    'page_key' => 'home',
                    'section_key' => '',
                    'section_type' => 'content',
                    'is_active' => 1,
                    'sort_order' => 1,
                    'translations' => [
                        'fa' => ['badge' => '', 'title' => '', 'subtitle' => '', 'description' => ''],
                        'en' => ['badge' => '', 'title' => '', 'subtitle' => '', 'description' => ''],
                        'ar' => ['badge' => '', 'title' => '', 'subtitle' => '', 'description' => ''],
                    ],
                ];
            }
        }

        return [
            'view' => 'admin.home-sections.edit',
            'data' => [
                'title' => $isNew ? 'سکشن جدید' : 'ویرایش سکشن',
                'item' => $item,
                'saved' => (int)($_GET['saved'] ?? 0),
            ],
        ];
    }

    public function save(): void
    {
        $items = DataStore::read('home_sections');
        $id = (int)($_POST['id'] ?? 0);

        // Build translations - each field is separate and independent
        $payload = [
            'id' => $id > 0 ? $id : (count($items) + 1),
            'page_key' => 'home',
            'section_key' => trim($_POST['section_key'] ?? ''),
            'section_type' => trim($_POST['section_type'] ?? 'content'),
            'is_active' => (int)($_POST['is_active'] ?? 0),
            'sort_order' => (int)($_POST['sort_order'] ?? 1),
            'translations' => [
                'en' => [
                    'badge' => trim($_POST['badge_en'] ?? ''),
                    'title' => trim($_POST['title_en'] ?? ''),
                    'subtitle' => trim($_POST['subtitle_en'] ?? ''),
                    'description' => trim($_POST['description_en'] ?? ''),
                ],
                'fa' => [
                    'badge' => trim($_POST['badge_fa'] ?? ''),
                    'title' => trim($_POST['title_fa'] ?? ''),
                    'subtitle' => trim($_POST['subtitle_fa'] ?? ''),
                    'description' => trim($_POST['description_fa'] ?? ''),
                ],
                'ar' => [
                    'badge' => trim($_POST['badge_ar'] ?? ''),
                    'title' => trim($_POST['title_ar'] ?? ''),
                    'subtitle' => trim($_POST['subtitle_ar'] ?? ''),
                    'description' => trim($_POST['description_ar'] ?? ''),
                ],
            ],
        ];

        $updated = false;
        foreach ($items as $index => $item) {
            if ((int)($item['id'] ?? 0) === $payload['id']) {
                $items[$index] = $payload;
                $updated = true;
                break;
            }
        }

        if (!$updated) {
            $items[] = $payload;
        }

        DataStore::write('home_sections', $items);
        arasb_redirect('/admin/home-sections/edit?id=' . $payload['id'] . '&saved=1');
    }
}
