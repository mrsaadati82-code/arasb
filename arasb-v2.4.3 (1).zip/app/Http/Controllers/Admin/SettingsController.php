<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class SettingsController
{
    private function fontOptions(): array
    {
        return [
            ['value' => 'default', 'label' => 'پیش‌فرض فعلی (Tahoma / Arial)'],
            ['value' => 'dana', 'label' => 'Dana'],
            ['value' => 'iransans', 'label' => 'IRANSans'],
            ['value' => 'iranyekan', 'label' => 'IRANYekan'],
            ['value' => 'kalameh', 'label' => 'Kalameh'],
            ['value' => 'peyda', 'label' => 'Peyda'],
        ];
    }

    public function index(): array
    {
        $items = DataStore::read('settings');
        $settings = [];

        foreach ($items as $item) {
            $settings[$item['setting_key']] = $item['value'] ?? '';
        }

        return [
            'view' => 'admin.settings.index',
            'data' => [
                'title' => 'تنظیمات سایت',
                'settings' => $settings,
                'fontOptions' => $this->fontOptions(),
                'saved' => (int)($_GET['saved'] ?? 0),
            ],
        ];
    }

    public function save(): void
    {
        $items = DataStore::read('settings');
        $values = [
            'company_name' => trim($_POST['company_name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'site_title' => trim($_POST['site_title'] ?? ''),
            'primary_domain' => trim($_POST['primary_domain'] ?? ''),
            'default_language' => trim($_POST['default_language'] ?? 'fa'),
            'font_family' => trim($_POST['font_family'] ?? 'default'),
            // SMTP settings
            'smtp_host' => trim($_POST['smtp_host'] ?? ''),
            'smtp_port' => trim($_POST['smtp_port'] ?? '587'),
            'smtp_username' => trim($_POST['smtp_username'] ?? ''),
            'smtp_password' => trim($_POST['smtp_password'] ?? ''),
            'smtp_encryption' => trim($_POST['smtp_encryption'] ?? 'tls'),
            'smtp_from_email' => trim($_POST['smtp_from_email'] ?? ''),
            'smtp_from_name' => trim($_POST['smtp_from_name'] ?? ''),
        ];

        foreach ($items as $index => $item) {
            $key = $item['setting_key'] ?? '';
            if (isset($values[$key])) {
                $items[$index]['value'] = $values[$key];
                unset($values[$key]);
            }
        }

        $nextId = count($items) + 1;
        foreach ($values as $key => $value) {
            $group = str_starts_with($key, 'smtp_') ? 'smtp' : 'appearance';
            $items[] = [
                'id' => $nextId++,
                'group_key' => $group,
                'setting_key' => $key,
                'label' => $key,
                'value' => $value,
            ];
        }

        DataStore::write('settings', $items);
        arasb_redirect('/admin/settings?saved=1');
    }
}
