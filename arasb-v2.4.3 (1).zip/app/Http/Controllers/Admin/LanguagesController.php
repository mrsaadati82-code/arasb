<?php

namespace App\Http\Controllers\Admin;

use App\Support\DataStore;

class LanguagesController
{
    public function index(): array
    {
        return [
            'view' => 'admin.languages.index',
            'data' => [
                'title' => 'مدیریت زبان‌ها',
                'items' => DataStore::read('languages'),
            ],
        ];
    }
}
