<?php

namespace App\Http\Middleware;

class SetLocale
{
    public function handle(string $locale): string
    {
        $allowed = ['fa', 'en', 'ar'];
        return in_array($locale, $allowed, true) ? $locale : 'en';
    }
}
