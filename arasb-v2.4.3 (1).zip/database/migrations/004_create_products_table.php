<?php

return [
    "CREATE TABLE IF NOT EXISTS `products` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `slug` VARCHAR(255) NOT NULL,
        `image` VARCHAR(500) DEFAULT NULL,
        `status` VARCHAR(30) NOT NULL DEFAULT 'published',
        `sort_order` INT NOT NULL DEFAULT 0,
        `category` TEXT DEFAULT NULL,
        `translations` LONGTEXT DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];
