<?php

return [
    "CREATE TABLE IF NOT EXISTS `contact_submissions` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `full_name` VARCHAR(255) NOT NULL,
        `email` VARCHAR(255) NOT NULL,
        `mobile` VARCHAR(50) DEFAULT NULL,
        `company_name` VARCHAR(255) DEFAULT NULL,
        `country` VARCHAR(100) DEFAULT NULL,
        `subject` VARCHAR(500) DEFAULT NULL,
        `message` TEXT NOT NULL,
        `language_code` VARCHAR(5) DEFAULT 'en',
        `source_page` VARCHAR(100) DEFAULT 'contact',
        `status` VARCHAR(30) NOT NULL DEFAULT 'new',
        `ip_address` VARCHAR(50) DEFAULT NULL,
        `user_agent` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];
