<?php

return [
    "CREATE TABLE IF NOT EXISTS `media` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `filename` VARCHAR(500) NOT NULL,
        `original_name` VARCHAR(500) NOT NULL,
        `mime_type` VARCHAR(100) NOT NULL,
        `size` BIGINT UNSIGNED NOT NULL DEFAULT 0,
        `path` VARCHAR(1000) NOT NULL,
        `alt_text` VARCHAR(500) DEFAULT NULL,
        `uploaded_by` INT UNSIGNED DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];
