<?php

return [
    "CREATE TABLE IF NOT EXISTS `home_sections` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `page_key` VARCHAR(100) NOT NULL DEFAULT 'home',
        `section_key` VARCHAR(150) NOT NULL,
        `section_type` VARCHAR(100) NOT NULL DEFAULT 'content',
        `is_active` TINYINT(1) NOT NULL DEFAULT 1,
        `sort_order` INT NOT NULL DEFAULT 0,
        `translations` LONGTEXT DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];
