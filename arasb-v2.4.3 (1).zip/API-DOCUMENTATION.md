# ARASB API Documentation v2.2.0

## Base URL
```
https://yourdomain.com/api
```

## Endpoints

### 1. Settings
**GET** `/api/settings`

Returns public site settings (SMTP and sensitive data excluded).

**Response:**
```json
{
  "success": true,
  "data": {
    "company_name": "ARASB Trading",
    "email": "info@arasbtrading.com",
    "phone": "+98 21 0000 0000",
    "site_title": "ARASB Trading",
    "primary_domain": "arasbtrading.com",
    "default_language": "fa",
    "font_family": "default"
  }
}
```

---

### 2. Languages
**GET** `/api/languages`

Returns available languages.

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "code": "fa",
      "name": "Persian",
      "native_name": "فارسی",
      "direction": "rtl",
      "is_active": 1
    }
  ]
}
```

---

### 3. Home Sections
**GET** `/api/home-sections?locale=fa`

Returns homepage sections with translations.

**Parameters:**
- `locale` (optional): Language code (fa/en/ar), default: en

**Response:**
```json
{
  "success": true,
  "locale": "fa",
  "data": [
    {
      "id": 1,
      "page_key": "home",
      "section_key": "hero",
      "section_type": "hero",
      "is_active": 1,
      "sort_order": 1,
      "translation": {
        "badge": "شریک صادراتی پیشرو",
        "title": "دسترسی شما را توانمند می‌سازیم به",
        "subtitle": "صادرات ممتاز ایرانی",
        "description": "متخصص در تأمین محصولات ممتاز ایرانی..."
      },
      "translations": { ... }
    }
  ]
}
```

---

### 4. Products List
**GET** `/api/products?locale=fa`

Returns list of published products.

**Parameters:**
- `locale` (optional): Language code (fa/en/ar), default: en

**Response:**
```json
{
  "success": true,
  "locale": "fa",
  "total": 5,
  "data": [
    {
      "id": 1,
      "slug": "premium-saffron",
      "image": "/uploads/saffron.jpg",
      "category": "ادویه‌جات",
      "sort_order": 1,
      "title": "زعفران ممتاز",
      "description": "زعفران درجه یک ایرانی..."
    }
  ]
}
```

---

### 5. Product Detail ✨ NEW
**GET** `/api/product-detail?slug=premium-saffron&locale=fa`

Returns detailed information about a specific product.

**Parameters:**
- `slug` (required): Product slug
- `locale` (optional): Language code (fa/en/ar), default: en

**Response:**
```json
{
  "success": true,
  "locale": "fa",
  "data": {
    "id": 1,
    "slug": "premium-saffron",
    "image": "/uploads/saffron.jpg",
    "category": "ادویه‌جات",
    "sort_order": 1,
    "title": "زعفران ممتاز",
    "description": "زعفران درجه یک ایرانی...",
    "subtitle": "بهترین کیفیت",
    "features": "ویژگی‌های محصول...",
    "gallery": [],
    "meta_title": "زعفران ممتاز | ARASB Trading",
    "meta_description": "زعفران درجه یک ایرانی...",
    "translations": { ... }
  }
}
```

**Errors:**
- `400` - Slug is required
- `404` - Product not found

---

### 6. Page Detail ✨ NEW
**GET** `/api/page-detail?slug=about&locale=fa`

Returns detailed information about a specific page.

**Parameters:**
- `slug` (required): Page slug
- `locale` (optional): Language code (fa/en/ar), default: en

**Response:**
```json
{
  "success": true,
  "locale": "fa",
  "data": {
    "id": 1,
    "slug": "about",
    "title": "درباره ما",
    "content": "محتوای صفحه...",
    "excerpt": "خلاصه...",
    "meta_title": "درباره ما | ARASB Trading",
    "meta_description": "توضیحات...",
    "translations": { ... }
  }
}
```

**Errors:**
- `400` - Slug is required
- `404` - Page not found

---

### 7. Search ✨ NEW
**GET** `/api/search?q=زعفران&locale=fa`

Search products by keyword.

**Parameters:**
- `q` (required): Search query
- `locale` (optional): Language code (fa/en/ar), default: en

**Response:**
```json
{
  "success": true,
  "locale": "fa",
  "query": "زعفران",
  "total": 2,
  "data": [
    {
      "id": 1,
      "slug": "premium-saffron",
      "image": "/uploads/saffron.jpg",
      "category": "ادویه‌جات",
      "title": "زعفران ممتاز",
      "description": "زعفران درجه یک ایرانی..."
    }
  ]
}
```

---

### 8. Contact Form Submission
**POST** `/api/contact-submit`

Submit contact form.

**Content-Type:** `application/json` or `multipart/form-data`

**Request Body:**
```json
{
  "full_name": "John Doe",
  "email": "john@example.com",
  "mobile": "+1234567890",
  "company_name": "ACME Corp",
  "country": "USA",
  "subject": "Inquiry about products",
  "message": "I would like to know more about...",
  "language_code": "en",
  "source_page": "contact"
}
```

**Required Fields:**
- `full_name`
- `email`
- `message`

**Response:**
```json
{
  "success": true,
  "message": "Your message has been received successfully.",
  "email_notification": true
}
```

**Errors:**
- `422` - Required fields are missing
- `422` - Invalid email address

**Email Notification:**
If SMTP is configured in admin settings, an email notification will be sent to the admin email address.

---

## CORS Headers

All API endpoints include CORS headers:
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type
```

---

## Error Responses

All errors follow this format:
```json
{
  "success": false,
  "message": "Error description"
}
```

**Common Status Codes:**
- `200` - Success
- `400` - Bad Request (missing required parameters)
- `404` - Not Found
- `422` - Validation Error
- `500` - Server Error

---

## Testing

### Using curl:
```bash
# Get products
curl "https://yourdomain.com/api/products?locale=fa"

# Get product detail
curl "https://yourdomain.com/api/product-detail?slug=premium-saffron&locale=fa"

# Search
curl "https://yourdomain.com/api/search?q=زعفران&locale=fa"

# Submit contact form
curl -X POST "https://yourdomain.com/api/contact-submit" \
  -H "Content-Type: application/json" \
  -d '{
    "full_name": "John Doe",
    "email": "john@example.com",
    "message": "Test message"
  }'
```

### Using JavaScript (fetch):
```javascript
// Get products
const response = await fetch('/api/products?locale=fa');
const data = await response.json();

// Get product detail
const response = await fetch('/api/product-detail?slug=premium-saffron&locale=fa');
const data = await response.json();

// Search
const response = await fetch('/api/search?q=زعفران&locale=fa');
const data = await response.json();

// Submit contact form
const response = await fetch('/api/contact-submit', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    full_name: 'John Doe',
    email: 'john@example.com',
    message: 'Test message'
  })
});
const data = await response.json();
```

---

## SMTP Configuration

To enable email notifications for contact form:

1. Go to Admin Panel → Settings
2. Fill in SMTP settings:
   - SMTP Host (e.g., smtp.gmail.com)
   - SMTP Port (e.g., 587)
   - SMTP Username
   - SMTP Password
   - SMTP Encryption (tls/ssl)
   - From Email
   - From Name
3. Save settings

**Note:** For Gmail, you may need to use an App Password instead of your regular password.

---

**Version:** 2.2.0  
**Last Updated:** 2026-07-03
