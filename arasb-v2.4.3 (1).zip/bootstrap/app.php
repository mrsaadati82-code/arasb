<?php

return [
    'name' => 'ARASB',
    'locales' => ['fa', 'en', 'ar'],
    'fallback_locale' => 'en',
    'base_path' => dirname(__DIR__),
];
