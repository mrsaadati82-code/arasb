<?php
/**
 * ARASB Dynamic Font CSS
 * Reads font_family setting from datastore and outputs CSS that overrides
 * Tailwind's --font-sans variable so the selected font applies site-wide.
 * When font is "default", no overrides are emitted (Tailwind uses its own font).
 */
header('Content-Type: text/css; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Expires: 0');
header('Pragma: no-cache');

require_once __DIR__ . '/../app/Support/DataStore.php';

$items = \App\Support\DataStore::read('settings');
$settings = [];
foreach ($items as $item) {
    $settings[$item['setting_key']] = $item['value'] ?? '';
}

$font = $settings['font_family'] ?? 'default';

$fontMap = [
    'dana'     => "'Dana', Tahoma, Arial, sans-serif",
    'iransans' => "'IRANSans', Tahoma, Arial, sans-serif",
    'iranyekan'=> "'IRANYekan', Tahoma, Arial, sans-serif",
    'kalameh'  => "'Kalameh', Tahoma, Arial, sans-serif",
    'peyda'    => "'Peyda', Tahoma, Arial, sans-serif",
];

echo "/* ARASB Dynamic Font CSS | font=$font | generated " . date('c') . " */\n";

if ($font !== 'default' && isset($fontMap[$font])) {
    $family = $fontMap[$font];
    // Override Tailwind's --font-sans so ALL Tailwind font utilities pick up the selected font
    // Our unlayered :root rule beats Tailwind's @layer theme { :root } rule in the cascade
    echo ":root {\n";
    echo "  --font-sans: $family;\n";
    echo "  --default-font-family: var(--font-sans);\n";
    echo "  --arasb-active-font: $family;\n";
    echo "}\n";
    // For admin panel body (uses --arasb-active-font via admin.css)
    echo "body.admin-body { font-family: var(--arasb-active-font) !important; }\n";
}
