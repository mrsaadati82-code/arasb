<?php
header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/../app/Support/DataStore.php';
$settings = [];
foreach (\App\Support\DataStore::read('settings') as $item) {
    $settings[$item['setting_key']] = $item['value'] ?? '';
}
$font = $settings['font_family'] ?? 'default';
?><!DOCTYPE html>
<html lang="fa" dir="rtl" data-arasb-font="<?php echo htmlspecialchars($font, ENT_QUOTES, 'UTF-8'); ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ARASB Font Debug</title>
  <link rel="stylesheet" href="/assets/css/fonts.css">
  <style>
    body{font-family:var(--arasb-active-font, Tahoma, Arial, sans-serif)!important;padding:32px;background:#f8fafc;color:#0f172a}
    .card{background:#fff;border-radius:20px;padding:24px;box-shadow:0 10px 30px rgba(15,23,42,.08);margin-bottom:20px}
    .sample{font-family:var(--arasb-active-font, Tahoma, Arial, sans-serif)!important;font-size:36px;line-height:1.8}
    code{direction:ltr;display:block;background:#0f172a;color:#fff;padding:12px;border-radius:12px;margin-top:10px}
  </style>
</head>
<body data-arasb-font="<?php echo htmlspecialchars($font, ENT_QUOTES, 'UTF-8'); ?>">
  <div class="card">
    <h1>دیباگ فونت آراسب</h1>
    <p>فونت ذخیره‌شده در تنظیمات:</p>
    <code><?php echo htmlspecialchars($font, ENT_QUOTES, 'UTF-8'); ?></code>
    <p>data-arasb-font روی html:</p>
    <code><?php echo htmlspecialchars($font, ENT_QUOTES, 'UTF-8'); ?></code>
  </div>
  <div class="card sample">
    این یک متن تست برای بررسی اعمال فونت انتخابی در پنل و سایت است.
    ۱۲۳۴۵۶۷۸۹۰
  </div>
</body>
</html>
