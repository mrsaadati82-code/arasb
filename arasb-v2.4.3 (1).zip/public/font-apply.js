(function(){
  function applyFont(font){
    if(!font) font = 'default';
    document.documentElement.setAttribute('data-arasb-font', font);
    if(document.body){
      document.body.setAttribute('data-arasb-font', font);
      document.body.style.setProperty('font-family', 'var(--arasb-active-font, Tahoma, Arial, sans-serif)', 'important');
    }
    var styleId = 'arasb-font-force-style';
    var style = document.getElementById(styleId);
    if(!style){
      style = document.createElement('style');
      style.id = styleId;
      document.head.appendChild(style);
    }
    style.textContent = 'html[data-arasb-font], body[data-arasb-font], body.admin-body, body.site-body, body{font-family:var(--arasb-active-font, Tahoma, Arial, sans-serif)!important;} body.admin-body *, body.site-body *, body *{font-family:inherit!important;}';
  }

  function loadFont(){
    try {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', '/api/settings', false);
      xhr.send(null);
      if(xhr.status >= 200 && xhr.status < 300){
        var payload = JSON.parse(xhr.responseText || '{}');
        var font = (payload.data && payload.data.font_family) ? payload.data.font_family : 'default';
        applyFont(font);
      } else {
        applyFont('default');
      }
    } catch (e) {
      applyFont('default');
    }
  }

  loadFont();
  document.addEventListener('DOMContentLoaded', loadFont);
  window.addEventListener('load', loadFont);
})();
